/**
 * @param lowest  assessed value of all the entries.
 * @param highest assessed value of all the entries.
 * @author Arshdeep Singh
 */
public record PropertyAssessedValues(long lowest, long highest, long range) {
    @Override
    public String toString() {
        return "min = $" + lowest + "\n" +
                "max = $" + highest + "\n" +
                "range = $" + range;
    }
}
