import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ApiRequest {
    /**
     * Endpoint to make API requests.
     */
    private static final String ENDPOINT = "https://data.edmonton.ca/resource/q7d6-ambg.csv";

    /**
     * Name of the custom header used for authentication.
     */
    private static final String APP_TOKEN_HEADER_NAME = "X-App-Token";

    /**
     * Authentication token used to authenticate for API requests.
     */
    private static final String APP_TOKEN_HEADER_VALUE = "PQb1ihYiY7aHyyrq82CcvonWv";

    /**
     * Limit the response results to 1000.
     */
    private static final int RESULTS_LIMIT = 1000;

    private final OkHttpClient client = new OkHttpClient();

    private final String endpointExtension;

    private final boolean isWithLimit;


    /**
     * Private constructor for the object, construction should only be done through the builder.
     *
     * @param endpointExtension query parameters to filter the requests.
     * @param isWithLimit       indicates whether to fetch a limited number of results or all the results.
     */
    private ApiRequest(String endpointExtension, boolean isWithLimit) {
        this.endpointExtension = endpointExtension;
        this.isWithLimit = isWithLimit;
    }

    /**
     * Adds limit and offset query parameters to the url.
     *
     * @param endpointExtension endpoint to add query parameters.
     * @param limit             value of limit as query parameter.
     * @param offset            value of offset as query parameter.
     * @return string with limit and offset query parameters appended.
     */
    private String addLimitAndOffset(String endpointExtension, int limit, int offset) {
        String result = endpointExtension;

        // Check if previous query parameters exist, if so append to the list of query parameters.
        if (endpointExtension.contains("?")) {
            result += "&";
        } else {
            // Else create a new list of query parameters.
            result += "?";
        }


        result += "$limit=" + limit + "&";
        result += "$offset=" + offset;

        return result;
    }

    /**
     * Makes api request to given route.
     *
     * @param endpointExtension endpoint to make the HTTP request.
     * @return Reader with the response body.
     * @throws IOException if the request is unsuccessful.
     */
    private Reader makeApiRequest(String endpointExtension) throws IOException {
        Request request = new Request.Builder().
                url(ENDPOINT + endpointExtension).
                addHeader(APP_TOKEN_HEADER_NAME, APP_TOKEN_HEADER_VALUE).
                build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                return null;
            }

            ResponseBody body = response.body();
            if (body == null) {
                return null;
            }

            return new StringReader(body.string());
        }
    }

    /**
     * Makes the api request, and parses the response body into a list of property assessment objects.
     *
     * @return List of property assessment objects.
     * @throws IOException If the request is unsuccessful.
     */
    private List<PropertyAssessment> makeApiRequestAndParseResponse() throws IOException {
        List<PropertyAssessment> results = new ArrayList<>();

        // If the limit is provided, do not make repeated requests in a loop.
        if (isWithLimit) {
            try (Reader reader = makeApiRequest(endpointExtension)) {
                if (reader == null) {
                    return results;
                }

                List<PropertyAssessment> parsedResults = Utility.csvToPropertyAssessments(reader, Constants.OPEN_CSV_PROFILE_API);

                return Objects.requireNonNullElse(parsedResults, results);
            }
        }

        int limit = 0;
        int offset = 0;

        // Repeat the requests until all the valid data is fetched.
        while (true) {
            String endpoint = endpointExtension;

            if (!isWithLimit) {
                offset += limit;
                limit = RESULTS_LIMIT;

                endpoint = addLimitAndOffset(endpoint, limit, offset);
            }

            try (Reader reader = makeApiRequest(endpoint)) {
                if (reader == null) {
                    break;
                }

                List<PropertyAssessment> parsedResults = Utility.csvToPropertyAssessments(reader, Constants.OPEN_CSV_PROFILE_API);
                if (parsedResults == null || parsedResults.size() == 0) {
                    break;
                }

                results.addAll(parsedResults);
            }
        }

        return results;
    }


    /**
     * Sends the request, and parses the response body.
     *
     * @return list of property assessment objects.
     * @throws IOException If the request is unsuccessful.
     */
    public List<PropertyAssessment> execute() throws IOException {
        return makeApiRequestAndParseResponse();
    }

    /**
     * Builder is used to create the ApiRequest objects.
     */
    public static class Builder {
        private int limit;

        private int offset;

        private int accountNumber;

        private String neighbourhood = "";

        private String address = "";

        private String assessmentClass = "";

        private int minAssessedValue;

        private int maxAssessedValue;

        private boolean isWhereClauseApplied;

        /**
         * Add offset to the request.
         *
         * @param offset number of records to skip.
         * @return this
         */
        public Builder withOffset(int offset) {
            this.offset = offset;
            return this;
        }

        /**
         * Add limit to the request.
         *
         * @param limit the number of results to get back.
         * @return this
         */
        public Builder withLimit(int limit) {
            this.limit = limit;
            return this;
        }

        /**
         * Add account number to the request.
         *
         * @param accountNumber the account number to fetch the request.
         * @return this
         */
        public Builder withAccountNumber(int accountNumber) {
            this.accountNumber = accountNumber;
            return this;
        }

        /**
         * Add neighbourhood to the request.
         *
         * @param neighbourhood the neighbourhood for the request entries.
         * @return this
         */
        public Builder withNeighbourhood(String neighbourhood) {
            this.neighbourhood = neighbourhood;
            return this;
        }

        /**
         * Add address to the request.
         *
         * @param address the address for request entries.
         * @return this
         */
        public Builder withAddress(String address) {
            this.address = address;
            return this;
        }

        /**
         * Add assessment class to the request.
         *
         * @param assessmentClass for the request entries.
         * @return this
         */
        public Builder withAssessmentClass(String assessmentClass) {
            this.assessmentClass = assessmentClass;
            return this;
        }

        /**
         * Add min and max range for the assessed values to the request.
         *
         * @param min min assessed value
         * @param max max assessed value
         * @return this
         */
        public Builder withAssessedValueRange(int min, int max) {
            this.minAssessedValue = min;
            this.maxAssessedValue = max;

            return this;
        }

        /**
         * Constructs a new api request object.
         *
         * @return Constructed ApiRequest object.
         */
        public ApiRequest build() {
            String endpoint = "?";
            boolean isWithLimit = false;

            // Add limit and offset to the request.
            if (limit != 0) {
                endpoint += "$limit=" + limit + "&";
                isWithLimit = true;
            }
            if (offset != 0) {
                endpoint += "$offset=" + offset + "&";
            }

            if (accountNumber != 0) {
                endpoint += "account_number=" + accountNumber + "&";
            }

            // Add where clause to the request, if any of the below properties are present.
            if (!"".equals(neighbourhood) || !"".equals(address) ||
                    !"".equals(assessmentClass) ||
                    minAssessedValue != 0 || maxAssessedValue != 0) {
                endpoint += "$where=";
            }

            // For neighbourhood check for either the neighbourhood or the war
            if (!"".equals(neighbourhood)) {
                endpoint += "neighbourhood like '%25" + URLEncoder.encode(neighbourhood.toUpperCase(), StandardCharsets.UTF_8) + "%25'";

                isWhereClauseApplied = true;
            }

            // Match address.
            if (!"".equals(address)) {
                if (isWhereClauseApplied) {
                    endpoint += "%20and%20";
                }

//                endpoint += "(suite='" + address + "' OR " +
//                        "house_number='" + address + "' OR " +
//                        "street_name='" + address + "')";

                endpoint += "suite%20%7C%7C%20house_number%20%7C%7C%20street_name%20like" +
                        "'%25" + URLEncoder.encode(address.toUpperCase(), StandardCharsets.UTF_8) + "%25'";

                isWhereClauseApplied = true;
            }

            // Match any of the assessment classes.
            if (!"".equals(assessmentClass)) {
                if (isWhereClauseApplied) {
                    endpoint += "%20and%20";
                }

                endpoint += "(mill_class_1='" + assessmentClass + "' OR " +
                        "mill_class_2='" + assessmentClass + "' OR " +
                        "mill_class_3='" + assessmentClass + "')";

                isWhereClauseApplied = true;
            }

            // Match within assessed value ranges.
            if (minAssessedValue != 0 && maxAssessedValue != 0) {
                if (isWhereClauseApplied) {
                    endpoint += "%20and%20";
                }

                endpoint += "(assessed_value >= " + minAssessedValue + "%20and%20" +
                        "assessed_value <= " + maxAssessedValue + ")";
            } else if (minAssessedValue != 0) {
                if (isWhereClauseApplied) {
                    endpoint += "%20and%20";
                }

                endpoint += "(assessed_value >= " + minAssessedValue + ")";
            } else if (maxAssessedValue != 0) {
                if (isWhereClauseApplied) {
                    endpoint += "%20and%20";
                }

                endpoint += "(assessed_value <= " + maxAssessedValue + ")";
            }

            // Remove the ampersand at the end if present.
            if (endpoint.lastIndexOf("&") + 1 == endpoint.length()) {
                endpoint = endpoint.substring(0, endpoint.length() - 1);
            }

            return new ApiRequest(endpoint, isWithLimit);
        }
    }

}
