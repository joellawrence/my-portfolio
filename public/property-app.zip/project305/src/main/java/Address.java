import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByNames;

import java.util.Objects;

/**
 * @author Arshdeep Singh
 */
public class Address {
    @CsvBindByNames({
            @CsvBindByName(column = "Suite", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "suite", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final String suite;

    @CsvBindByNames({
            @CsvBindByName(column = "House Number", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "house_number", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final int houseNumber;

    @CsvBindByNames({
            @CsvBindByName(column = "Street Name", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "street_name", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final String streetName;

    /**
     * Default constructor for the object. Sets all the fields to their default
     * values.
     */
    public Address() {
        this("", 0, "");
    }

    /**
     * Constructor for the object.
     *
     * @param suite       for the address.
     * @param houseNumber of the address.
     * @param streetName  of the address.
     */
    public Address(String suite, int houseNumber, String streetName) {
        this.suite = suite;
        this.houseNumber = houseNumber;
        this.streetName = streetName;
    }

    /**
     * @return suite of a given address.
     */
    public String getSuite() {
        return suite;
    }

    /**
     * @return house number of a given address.
     */
    public int getHouseNumber() {
        return houseNumber;
    }

    /**
     * @return name of the street for a given address.
     */
    public String getStreetName() {
        return streetName;
    }

    /**
     * Provides a string representation of the address.
     *
     * @return representation of object.
     */
    @Override
    public String toString() {
        return suite + " " + houseNumber + " " + streetName;
    }

    /**
     * Compares two objects based on their assessed values.
     *
     * @param o other object to compare with current object.
     * @return true/false if the fields are same for both objects.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Address address = (Address) o;

        if (houseNumber != address.houseNumber) {
            return false;
        }
        if (!Objects.equals(suite, address.suite)) {
            return false;
        }
        return Objects.equals(streetName, address.streetName);
    }

    /**
     * Calculates the hashcode of the object, based on its member fields.
     *
     * @return integer representing the calculated hash code of the object.
     */
    @Override
    public int hashCode() {
        int result = suite != null ? suite.hashCode() : 0;
        result = 31 * result + houseNumber;
        result = 31 * result + (streetName != null ? streetName.hashCode() : 0);
        return result;
    }
}
