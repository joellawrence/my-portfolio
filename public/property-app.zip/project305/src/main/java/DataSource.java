/**
 * @author Arshdeep Singh
 */
public enum DataSource {
    /**
     * File is used to indicate the data source as file.
     */
    FILE {
        @Override
        public String toString() {
            return "CSV File";
        }
    },
    /**
     * Api is used to indicate the data source as api.
     */
    API {
        @Override
        public String toString() {
            return "Edmonton's Open Data Portal";
        }
    }
}
