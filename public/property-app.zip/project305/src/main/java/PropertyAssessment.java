import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByNames;
import com.opencsv.bean.CsvRecurse;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;

/**
 * @author Arshdeep Singh
 */
public class PropertyAssessment implements Comparable<PropertyAssessment> {
    /**
     * Account number of the user.
     */
    @CsvBindByNames({
            @CsvBindByName(column = "Account Number", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "account_number", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final int accountNumber;
    private String valueString;

    /**
     * Address where the assessment was done.
     */
    @CsvRecurse
    private final Address address;

    /**
     * To check if the property has a garage.
     *
     * @implNote: opencsv automatically converts Y/N values to boolean values.
     */
    @CsvBindByNames({
            @CsvBindByName(column = "Garage", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "garage", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final boolean withGarage;

    /**
     * Neighbourhood information about the property.
     */
    @CsvRecurse
    private final Neighbourhood neighbourhood;

    /**
     * Assessed value of the property.
     */
    @CsvBindByNames({
            @CsvBindByName(column = "Assessed Value", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "assessed_value", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final long assessedValue;

    /**
     * Geographic location of the property.
     */
    @CsvRecurse
    private final Location location;
    /**
     * Different types of assessment classes for the property.
     */
    @CsvRecurse
    private final AssessmentClass assessmentClass;

    /**
     * Default constructor for the object. Sets all the fields to their default
     * values.
     */
    public PropertyAssessment() {
        this(
                0,
                new Address(),
                false,
                new Neighbourhood(),
                0,
                new Location(),
                new AssessmentClass()
        );
    }

    /**
     * Constructor for the object.
     *
     * @param accountNumber   account number for property record.
     * @param address         address for the property.
     * @param withGarage      check if the property has a garage.
     * @param neighbourhood   neighbourhood where the property is located in.
     * @param assessedValue   assessed value of the property.
     * @param location        location of the property.
     * @param assessmentClass assessment class which the property is categorized in.
     */
    public PropertyAssessment(int accountNumber, Address address, boolean withGarage, Neighbourhood neighbourhood, long assessedValue, Location location, AssessmentClass assessmentClass) {
        this.accountNumber = accountNumber;
        this.address = address;
        this.withGarage = withGarage;
        this.neighbourhood = neighbourhood;
        this.assessedValue = assessedValue;
        this.location = location;
        this.assessmentClass = assessmentClass;
    }

    public String getValueString() { return "$" + NumberFormat.getNumberInstance(Locale.US).format(assessedValue); }

    /**
     * @return account number of the property assessment.
     */
    public int getAccountNumber() {
        return accountNumber;
    }

    /**
     * @return address of the property assessment.
     */
    public Address getAddress() {
        return address;
    }

    /**
     * @return whether the property has a garage.
     */
    public boolean isWithGarage() {
        return withGarage;
    }

    /**
     * @return neighbourhood for the property.
     */
    public Neighbourhood getNeighbourhood() {
        return neighbourhood;
    }

    /**
     * @return assessed value of the property.
     */
    public long getAssessedValue() {
        return assessedValue;
    }

    /**
     * @return location of the property.
     */
    public Location getLocation() {
        return location;
    }

    /**
     * @return assessment class information of the property.
     */
    public AssessmentClass getAssessmentClass() {
        return assessmentClass;
    }

    /**
     * Provides a string representation of the property assessment.
     *
     * @return representation of object.
     */
    @Override
    public String toString() {
        return "Account Number = " + accountNumber + "\n" +
                address + "\n" +
                "Assessed Value = $" + assessedValue + "\n" +
                assessmentClass + "\n" +
                neighbourhood + "\n" +
                location + "\n";
    }

    /**
     * Compares two objects based on their assessed values.
     *
     * @param other the object to be compared.
     * @return a negative value if the current object's assessed value is less than the
     * other object's assessed value, 0 if they are both equal, positive is current object's
     * assessed value is greater than other object's assessed value.
     */
    @Override
    public int compareTo(PropertyAssessment other) {
        return Long.compare(getAssessedValue(), other.getAssessedValue());
    }

    /**
     * Compares two objects based on their member fields.
     *
     * @param o other object to compare with current object.
     * @return true/false if the fields are same for both objects.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PropertyAssessment that = (PropertyAssessment) o;

        if (accountNumber != that.accountNumber) {
            return false;
        }
        if (withGarage != that.withGarage) {
            return false;
        }
        if (assessedValue != that.assessedValue) {
            return false;
        }
        if (!Objects.equals(address, that.address)) {
            return false;
        }
        if (!Objects.equals(neighbourhood, that.neighbourhood)) {
            return false;
        }
        if (!Objects.equals(location, that.location)) {
            return false;
        }

        return Objects.equals(assessmentClass, that.assessmentClass);
    }

    /**
     * Calculates the hashcode of the object, based on its member fields.
     *
     * @return integer representing the calculated hash code of the object.
     */
    @Override
    public int hashCode() {
        int result = accountNumber;
        result = 31 * result + (address != null ? address.hashCode() : 0);
        result = 31 * result + (withGarage ? 1 : 0);
        result = 31 * result + (neighbourhood != null ? neighbourhood.hashCode() : 0);
        result = 31 * result + (int) (assessedValue ^ (assessedValue >>> 32));
        result = 31 * result + (location != null ? location.hashCode() : 0);
        result = 31 * result + (assessmentClass != null ? assessmentClass.hashCode() : 0);
        return result;
    }

    /**
     * Converts the necessary properties to JSON objects, the objects are directly passed to Javascript
     * in web view.
     *
     * @return json objects string representation.
     */
    public String toJson() {
        return String.format("{ account: %d, lat: %f, lng: %f },",
                accountNumber,
                location.getLatitude(),
                location.getLongitude()
        );
    }
}
