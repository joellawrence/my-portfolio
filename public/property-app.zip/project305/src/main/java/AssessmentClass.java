import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByNames;

import java.util.Objects;

/**
 * @author Arshdeep Singh
 */
public class AssessmentClass {
    @CsvBindByNames({
            @CsvBindByName(column = "Assessment Class % 1", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "tax_class_pct_1", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final int assessmentClass1Percentage;

    @CsvBindByNames({
            @CsvBindByName(column = "Assessment Class 1", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "mill_class_1", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final String assessmentClass1;

    @CsvBindByNames({
            @CsvBindByName(column = "Assessment Class % 2", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "tax_class_pct_2", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final int assessmentClass2Percentage;

    @CsvBindByNames({
            @CsvBindByName(column = "Assessment Class 2", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "mill_class_2", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final String assessmentClass2;

    @CsvBindByNames({
            @CsvBindByName(column = "Assessment Class % 3", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "tax_class_pct_3", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final int assessmentClass3Percentage;

    @CsvBindByNames({
            @CsvBindByName(column = "Assessment Class 3", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "mill_class_3", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final String assessmentClass3;

    /**
     * Default constructor for the object. Sets all the fields to their default
     * values.
     */
    public AssessmentClass() {
        this(
                "", 0,
                "", 0,
                "", 0
        );
    }

    /**
     * Constructor for object.
     *
     * @param assessmentClass1           name.
     * @param assessmentClass1Percentage classification percentage for assessment class 1.
     * @param assessmentClass2           name.
     * @param assessmentClass2Percentage classification percentage for assessment class 2.
     * @param assessmentClass3           name.
     * @param assessmentClass3Percentage classification percentage for assessment class 3.
     */
    public AssessmentClass(String assessmentClass1, int assessmentClass1Percentage,
                           String assessmentClass2, int assessmentClass2Percentage,
                           String assessmentClass3, int assessmentClass3Percentage) {
        this.assessmentClass1 = assessmentClass1;
        this.assessmentClass1Percentage = assessmentClass1Percentage;

        this.assessmentClass2 = assessmentClass2;
        this.assessmentClass2Percentage = assessmentClass2Percentage;

        this.assessmentClass3 = assessmentClass3;
        this.assessmentClass3Percentage = assessmentClass3Percentage;
    }

    /**
     * @return percentage of assessment class 1.
     */
    public int getAssessmentClass1Percentage() {
        return assessmentClass1Percentage;
    }

    /**
     * @return name of assessment class 1.
     */
    public String getAssessmentClass1() {
        return assessmentClass1;
    }

    /**
     * @return percentage of assessment class 2.
     */
    public int getAssessmentClass2Percentage() {
        return assessmentClass2Percentage;
    }

    /**
     * @return name of assessment class 2.
     */
    public String getAssessmentClass2() {
        return assessmentClass2;
    }

    /**
     * @return percentage of assessment class 3.
     */
    public int getAssessmentClass3Percentage() {
        return assessmentClass3Percentage;
    }

    /**
     * @return name of assessment class 3.
     */
    public String getAssessmentClass3() {
        return assessmentClass3;
    }

    /**
     * Provides a string representation of the assessment class.
     *
     * @return representation of object.
     */
    @Override
    public String toString() {
        String result = "[ ";

        if (assessmentClass1Percentage != 0) {
            result += assessmentClass1 + " " + assessmentClass1Percentage + "% ";
        }
        if (assessmentClass2Percentage != 0) {
            result += ", " + assessmentClass2 + " " + assessmentClass2Percentage + "% ";
        }
        if (assessmentClass3Percentage != 0) {
            result += ", " + assessmentClass3 + " " + assessmentClass3Percentage + "% ";
        }

        return result + "]";
    }

    /**
     * Compares two objects based on their member fields.
     *
     * @param o other object to compare with current object.
     * @return true/false if the fields are same for both objects.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AssessmentClass that = (AssessmentClass) o;

        if (assessmentClass1Percentage != that.assessmentClass1Percentage) {
            return false;
        }
        if (assessmentClass2Percentage != that.assessmentClass2Percentage) {
            return false;
        }
        if (assessmentClass3Percentage != that.assessmentClass3Percentage) {
            return false;
        }
        if (!Objects.equals(assessmentClass1, that.assessmentClass1)) {
            return false;
        }
        if (!Objects.equals(assessmentClass2, that.assessmentClass2)) {
            return false;
        }

        return Objects.equals(assessmentClass3, that.assessmentClass3);
    }

    /**
     * Calculates the hashcode of the object, based on its member fields.
     *
     * @return integer representing the calculated hash code of the object.
     */
    @Override
    public int hashCode() {
        int result = assessmentClass1Percentage;
        result = 31 * result + (assessmentClass1 != null ? assessmentClass1.hashCode() : 0);
        result = 31 * result + assessmentClass2Percentage;
        result = 31 * result + (assessmentClass2 != null ? assessmentClass2.hashCode() : 0);
        result = 31 * result + assessmentClass3Percentage;
        result = 31 * result + (assessmentClass3 != null ? assessmentClass3.hashCode() : 0);
        return result;
    }
}
