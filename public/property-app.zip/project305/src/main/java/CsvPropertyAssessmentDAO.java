import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Arshdeep Singh
 */
public class CsvPropertyAssessmentDAO implements PropertyAssessmentDAO {
    private final List<PropertyAssessment> entries;

    /**
     * Filtered list is used to keep track of the list that is filtered through filter functions of api.
     */
    private List<PropertyAssessment> filteredList;

    /**
     * Constructor for object.
     *
     * @param filename name of the csv file.
     * @throws FileNotFoundException if file with given name does not exist.
     */
    public CsvPropertyAssessmentDAO(String filename)
            throws FileNotFoundException {
        Reader reader = new FileReader(filename);

        entries = Utility.csvToPropertyAssessments(reader, Constants.OPEN_CSV_PROFILE_FILE);
        filteredList = new ArrayList<>(entries);
    }


    /**
     * Get the entry by account number.
     *
     * @param accountNumber to find the entry.
     * @return optional entry if present.
     */
    @Override
    public Optional<PropertyAssessment> getByAccountNumber(int accountNumber) {
        Optional<PropertyAssessment> result = entries.stream().
                filter((assessment) -> assessment.getAccountNumber() == accountNumber).
                findFirst();

        return result;
    }

    /**
     * Get all the entries by the neighbourhood.
     *
     * @param neighbourhood to find all the entries for.
     * @return All the entries in a given neighbourhood.
     */
    @Override
    public List<PropertyAssessment> getByNeighbourhood(String neighbourhood) {
        return filterByNeighbourhood(neighbourhood).executeFilter();
    }

    /**
     * Get all the entries by the address.
     *
     * @param address to find all the entries.
     * @return All the entries for the given address.
     */
    @Override
    public List<PropertyAssessment> getByAddress(String address) {
        return filterByAddress(address).executeFilter();
    }

    /**
     * Get all the entries for a given assessment class.
     *
     * @param assessmentClass to find all the entries.
     * @return All the entries for the given assessment class.
     */
    @Override
    public List<PropertyAssessment> getByAssessmentClass(String assessmentClass) {
        return filterByAssessmentClass(assessmentClass).executeFilter();
    }

    /**
     * Get all the entries within min and max assessed value range.
     *
     * @param min lower range.
     * @param max higher range.
     * @return entries within the given range.
     */
    @Override
    public List<PropertyAssessment> getByAssessedValue(int min, int max) {
        return filterByAssessedValue(min, max).executeFilter();
    }

    /**
     * Get all the entries.
     *
     * @return all entries.
     */
    @Override
    public List<PropertyAssessment> getAll() {
        return new ArrayList<>(entries);
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by neighbourhood.
     *
     * @param neighbourhood filter by neighbourhood.
     * @return all entries in neighbourhood.
     */
    @Override
    public PropertyAssessmentDAO filterByNeighbourhood(String neighbourhood) {
        filteredList = filteredList.stream().
                filter((assessment) -> assessment.
                        getNeighbourhood().
                        getNeighbourhood().
                        toLowerCase().
                        contains(neighbourhood.toLowerCase())
                ).
                toList();


        return this;
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by address.
     *
     * @param address filter by address.
     * @return all entries in address.
     */
    @Override
    public PropertyAssessmentDAO filterByAddress(String address) {
        final String compareAddress = address.toLowerCase();

        // Address filter checks whether any of the address suite, house number or the name has the substring
        // address.
        filteredList = filteredList.stream().
                filter((assessment) ->
                        assessment.getAddress().getSuite().toLowerCase().contains(compareAddress) ||
                                assessment.getAddress().getStreetName().toLowerCase().contains(compareAddress) ||
                                String.format("%d", assessment.getAddress().getHouseNumber()).equalsIgnoreCase(address)
                ).
                toList();

        return this;
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by assessment class.
     *
     * @param assessmentClass filter by assessmentClass.
     * @return all entries in assessment class.
     */
    @Override
    public PropertyAssessmentDAO filterByAssessmentClass(String assessmentClass) {
        // Assessment class filter matches if any of the assessment classes have the given assessment filter.
        filteredList = filteredList.stream().
                filter((assessment) -> {
                    AssessmentClass assessmentClass1 = assessment.getAssessmentClass();

                    return assessmentClass1.getAssessmentClass1().equalsIgnoreCase(assessmentClass) ||
                            assessmentClass1.getAssessmentClass2().equalsIgnoreCase(assessmentClass) ||
                            assessmentClass1.getAssessmentClass3().equalsIgnoreCase(assessmentClass);
                }).
                toList();

        return this;
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by min and max assessed value range.
     *
     * @param min range of assessed value.
     * @param max range of assessed value.
     * @return entries that are within the range.
     */
    @Override
    public PropertyAssessmentDAO filterByAssessedValue(int min, int max) {
        // If both min and maximum are not provided, the filters are not applied therefore return the
        // object itself.
        if (min == -1 && max == -1) {
            return this;
        }

        // If max not provided, filter using the min value.
        if (max == -1) {
            filteredList = filteredList.stream().
                    filter((assessment) -> assessment.getAssessedValue() >= min).
                    toList();
        } else if (min == -1) {
            // Else filter only the max value.
            filteredList = filteredList.stream().
                    filter((assessment) -> assessment.getAssessedValue() <= max).
                    toList();
        } else {
            // Filter using both the minimum and maximum values.
            filteredList = filteredList.stream().
                    filter((assessment) -> assessment.getAssessedValue() >= min && assessment.getAssessedValue() <= max).
                    toList();
        }


        return this;
    }

    /**
     * Execute the filter chain.
     *
     * @return list after all the filters are applied.
     */
    @Override
    public List<PropertyAssessment> executeFilter() {
        // Assign the filtered list to a temporary variable.
        List<PropertyAssessment> temp = filteredList;

        // Reassign the state variable to new list.
        filteredList = new ArrayList<>(entries);

        return temp;
    }
}
