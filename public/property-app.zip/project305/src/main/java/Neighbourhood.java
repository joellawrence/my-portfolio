import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByNames;

import java.util.Objects;

/**
 * @author Arshdeep Singh
 */
public class Neighbourhood {
    @CsvBindByNames({
            @CsvBindByName(column = "Neighbourhood ID", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "neighbourhood_id", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final int neighbourhoodId;

    @CsvBindByNames({
            @CsvBindByName(column = "Neighbourhood", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "neighbourhood", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final String neighbourhood;

    @CsvBindByNames({
            @CsvBindByName(column = "Ward", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "ward", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final String ward;

    /**
     * Default constructor for the object. Sets all the fields to their default
     * values.
     */
    public Neighbourhood() {
        this(0, "", "");
    }

    /**
     * Constructor for object.
     *
     * @param neighbourhoodId id of the neighbourhood.
     * @param neighbourhood   name of the neighbourhood.
     * @param ward            name of the ward of the neighbourhood.
     */
    public Neighbourhood(int neighbourhoodId, String neighbourhood, String ward) {
        this.neighbourhoodId = neighbourhoodId;
        this.neighbourhood = neighbourhood;
        this.ward = ward;
    }

    /**
     * @return id of the neighbourhood.
     */
    public int getNeighbourhoodId() {
        return neighbourhoodId;
    }

    /**
     * @return name of the neighbourhood.
     */
    public String getNeighbourhood() {
        return neighbourhood;
    }

    /**
     * @return name of the ward.
     */
    public String getWard() {
        return ward;
    }

    /**
     * Provides a string representation of the neighbourhood.
     *
     * @return representation of object.
     */
    @Override
    public String toString() {
        return neighbourhood + " (" + ward + ")";
    }

    /**
     * Compares two objects based on their member fields.
     *
     * @param o other object to compare with current object.
     * @return true/false if the fields are same for both objects.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Neighbourhood that = (Neighbourhood) o;

        if (neighbourhoodId != that.neighbourhoodId) {
            return false;
        }
        if (!Objects.equals(neighbourhood, that.neighbourhood)) {
            return false;
        }
        return Objects.equals(ward, that.ward);
    }

    /**
     * Calculates the hashcode of the object, based on its member fields.
     *
     * @return integer representing the calculated hash code of the object.
     */
    @Override
    public int hashCode() {
        int result = neighbourhoodId;
        result = 31 * result + (neighbourhood != null ? neighbourhood.hashCode() : 0);
        result = 31 * result + (ward != null ? ward.hashCode() : 0);
        return result;
    }
}
