import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

import java.io.Reader;
import java.util.List;

/**
 * @author Arshdeep Singh
 */
public class Utility {
    /**
     * Parses the input csv from the reader, and returns the list of objects from csv.
     *
     * @param reader to input csv.
     * @return list of property assessments from the parsed csv.
     */
    public static List<PropertyAssessment> csvToPropertyAssessments(Reader reader, String profile) {
        // Build the csv parser.
        CsvToBean<PropertyAssessment> csvToBean = new CsvToBeanBuilder<PropertyAssessment>(reader).
                withType(PropertyAssessment.class).
                withProfile(profile).
                build();

        // Parse the csv file.
        List<PropertyAssessment> entries = csvToBean.parse();

        return entries;
    }

    /**
     * Converts the list of property assessments into their JSON representations.
     *
     * @param propertyAssessments list of property assessments.
     * @return json string representation of objects.
     */
    public static String propertyAssessmentsToJsonString(List<PropertyAssessment> propertyAssessments) {
        StringBuilder stringBuilder = new StringBuilder();

        // Beginning of the array.
        stringBuilder.append("[");

        // Append objects.
        propertyAssessments.forEach((assessment) -> {
            stringBuilder.append(assessment.toJson());
        });

        // End of the array.
        stringBuilder.append("]");

        return stringBuilder.toString();
    }
}
