/**
 * @param assessedValues of the properties, including lowest, highest, and range between values.
 * @param meanMedian     mean and median of the properties
 * @author Arshdeep Singh
 */
public record PropertyStatistics(int numberOfRecords, PropertyAssessedValues assessedValues,
                                 PropertyMeanMedian meanMedian) {
    @Override
    public String toString() {
        return "n = " + numberOfRecords + "\n" +
                assessedValues.toString() + "\n" +
                meanMedian;
    }
}
