import java.io.FileNotFoundException;
import java.util.Set;

/**
 * Main program that answers all the Lab 1 Questions.
 *
 * @author Arshdeep Singh
 */
public class Lab1Main {
    /**
     * Filename to parse by default.
     */
    private static final String FILENAME = "Property_Assessment_Data_2022.csv";

    public static void main(String[] args) {
        run();
    }

    /**
     * Main entry program for the lab 1 answers.
     */
    public static void run() {
        try {
            PropertyAssessments assessments = PropertyAssessments.loadFromCsv(FILENAME);

            System.out.println("----- Lab 1 -----");

            int numberRecords = assessments.numberOfRecords();
            PropertyAssessedValues values = assessments.lowestAndHighestAssessedValues();
            int numberWards = assessments.numberOfWards();
            Set<String> assessmentClasses = assessments.propertyAssessmentClasses();

            System.out.println("Number of records     : " + numberRecords);
            System.out.println("Lowest Assessed Value : " + values.lowest());
            System.out.println("Highest Assessed Value: " + values.highest());
            System.out.println("Number of wards       : " + numberWards);
            System.out.println();

            System.out.println("Assessment Classes:");
            for (String assessmentClass : assessmentClasses) {
                System.out.println(assessmentClass);
            }
        } catch (FileNotFoundException e) {
            System.err.println("File with name " + FILENAME + " not found.");
        } catch (IllegalStateException e) {
            // Print the stack trace for illegal state exception.
            e.printStackTrace();
        }
    }
}
