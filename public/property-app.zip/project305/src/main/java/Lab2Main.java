import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * @author Arshdeep Singh
 */
public class Lab2Main {
    public static void main(String[] args) {
        run();
    }

    /**
     * Main entry point for the lab 2 client program.
     */
    public static void run() {
        Scanner scanner = new Scanner(System.in);

        // Read filename from user.
        System.out.print("CSV filename: ");
        if (!scanner.hasNext()) {
            System.err.println("Invalid input");
            return;
        }
        String filename = scanner.nextLine();

        // Try loading the assessments data from file.
        PropertyAssessments assessments;
        try {
            assessments = PropertyAssessments.loadFromCsv(filename);
        } catch (FileNotFoundException e) {
            System.err.println("Error: cannot open file " + filename);
            return;
        } catch (IllegalStateException e) {
            e.printStackTrace();
            return;
        }

        // Print out statistics for all the loaded data.
        PropertyStatistics statistics = assessments.descriptiveStatistics();
        System.out.println("Descriptive statistics of all the property assessments");
        System.out.println(statistics);

        // Read account number from user, and print account entry.
        System.out.print("Find a property assessment by account number: ");
        int accountNumber = 0;
        try {
            accountNumber = scanner.nextInt();
        } catch (InputMismatchException exception) {
            System.err.println("Error: invalid account number...");
        }

        PropertyAssessment assessment = assessments.getEntryByAccountNumber(accountNumber);
        if (accountNumber == 0 || assessment == null) {
            scanner.nextLine();
            System.err.println("Sorry, account number not found.");
        } else {
            System.out.println(assessment);
        }

        System.out.print("Neighbourhood: ");
        // Read neighbourhood name from user, and print neighbourhood stats.
        String neighbourhood = scanner.nextLine();
        PropertyAssessments neighbourhoodAssessments = assessments.filterByNeighbourhood(neighbourhood);
        if (neighbourhoodAssessments.numberOfRecords() == 0) {
            System.out.println("Data not found");
            return;
        }

        PropertyStatistics neighbourhoodStatistics = neighbourhoodAssessments.descriptiveStatistics();
        System.out.println("Statistics (" + neighbourhood + ")");
        System.out.println(neighbourhoodStatistics);

        scanner.close();
    }
}
