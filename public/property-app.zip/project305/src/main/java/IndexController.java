import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

import java.io.FileNotFoundException;
import java.text.NumberFormat;
import java.util.*;

/**
 * @author arshdeepjodhka
 */
public class IndexController {
    private static final String APPLICATION_TITLE = "Edmonton Property Assessments 2022";
    private final NumberFormat currency = NumberFormat.getCurrencyInstance();

    private PropertyAssessmentDAO propertyAssessmentDAO;

    @FXML
    private TableColumn<PropertyAssessment, Integer> accountColumn;

    @FXML
    private TextField accountNumberTextField;

    @FXML
    private TableColumn<PropertyAssessment, Address> addressColumn;

    @FXML
    private TextField addressTextField;

    @FXML
    private TableColumn<PropertyAssessment, Long> assessedValueColumn;

    @FXML
    private BarChart<String, Integer> assessedValueBarChart;

    @FXML
    private PieChart assessedValuePieChart;

    @FXML
    private TableColumn<PropertyAssessment, AssessmentClass> assessmentClassColumn;

    @FXML
    private ComboBox<String> assessmentClassComboBox;

    @FXML
    private TableView<PropertyAssessment> assessmentsTable;

    @FXML
    private WebView browser;

    @FXML
    private ComboBox<DataSource> dataSourceComboBox;

    @FXML
    private TableColumn<PropertyAssessment, Location> locationColumn;

    @FXML
    private TextField maxTextField;

    @FXML
    private TextField minTextField;

    @FXML
    private TableColumn<PropertyAssessment, Neighbourhood> neighbourhoodColumn;

    @FXML
    private TextField neighbourhoodTextField;

    @FXML
    private Button resetButton;

    @FXML
    private Button searchButton;

    /**
     * Creates the html which is loaded directly into the web view to render google maps.
     *
     * @param jsonObjects list of assessment objects.
     * @return html
     */
    private static String createHtml(String jsonObjects) {
        // Html used to create the Google Maps web view.
        return """
                <!DOCTYPE html>
                <html lang="en">
                  <head>
                    <meta charset="UTF-8" />
                    <title>Title</title>
                    <style>
                      body {
                        margin: 0 !important;
                        padding: 0 !important;
                      }
                    </style>
                  </head>
                  <body>
                    <div id="map" style="position: absolute; width: 100%; height: 100%"></div>

                    <script>
                      assessments = """ + jsonObjects + """
                            
                      let mapFunctions = {};
                      
                      function initializeMap() {
                        mapFunctions = {};
                      
                        const map = new google.maps.Map(document.getElementById("map"), {
                          zoom: 13,
                          center: { lat: assessments[0].lat, lng: assessments[0].lng },
                        });
                      
                        assessments.forEach(({ account, lat, lng }) => {
                          const marker = new google.maps.Marker({
                            position: { lat, lng },
                            map,
                          });
                      
                          marker.addListener("click", (event) => {
                            map.setZoom(20);
                            map.setCenter(marker.getPosition());
                          });
                      
                          mapFunctions[`${account}`] = () => {
                            map.setZoom(20);
                            map.setCenter(marker.getPosition());
                          };
                        });
                      }
                      
                      window.initializeMap = initializeMap;
                    </script>
                  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCQSfbrQWDUuT3QCZkLikqN7T1Ih_Kp8o8&callback=initializeMap&v=weekly"></script>
                </body>
                </html>
                """;
    }

    /**
     * Initializes the GUI application.
     */
    @FXML
    void initialize() {
        // Fill combo box options.
        fillDataSourceComboOptions();
        fillAssessmentClassComboOptions();

        // Set width of each of the table columns.
        setTableColumnWidths();
        mapFieldsToColumnValues();
    }

    /**
     * Loads data from the given data source.
     *
     * @param event click event.
     */
    @FXML
    void loadDataClick(ActionEvent event) {
        loadData();

        // Disable the data source once the data is loaded.
        dataSourceComboBox.setDisable(true);

        List<PropertyAssessment> propertyAssessments = propertyAssessmentDAO.getAll().stream().
                limit(200).
                toList();
        fillDataForNodes(propertyAssessments);
    }

    /**
     * Resets the control fields, and the internal data list.
     *
     * @param event click event.
     */
    @FXML
    void resetClick(ActionEvent event) {
        clearControls();
        clearNodes();

        // Re enable combo box again.
        dataSourceComboBox.setDisable(false);
    }

    /**
     * Search implements the filters, and updates the list base on new search results.
     *
     * @param event click event.
     */
    @FXML
    void searchClick(ActionEvent event) {
        PropertyAssessmentDAO dao = propertyAssessmentDAO;
        if (dao == null) {
            GuiUtility.showWarningWindow(
                    "Invalid Data",
                    "Please select a data source and load data."
            );
            return;
        }

        // Input from account number text field.
        if (!"".equals(accountNumberTextField.getText())) {
            try {
                int accountNumber = Integer.parseInt(accountNumberTextField.getText());
                // Get the entry for the account number.
                Optional<PropertyAssessment> entry = dao.getByAccountNumber(accountNumber);

                if (entry.isEmpty()) {
                    GuiUtility.showWarningWindow(
                            "Search Results",
                            "Oops!, Cannot find a valid entry."
                    );
                    return;
                }

                List<PropertyAssessment> assessments = new ArrayList<>();
                assessments.add(entry.get());
                fillDataForNodes(assessments);
            } catch (NumberFormatException e) {
                GuiUtility.showWarningWindow(
                        "Invalid Input",
                        "Invalid account number!"
                );
            }

            return;
        }

        // Input from address text field.
        if (!"".equals(addressTextField.getText())) {
            dao = dao.filterByAddress(addressTextField.getText());
        }

        // Input from neighbourhood text field.
        if (!"".equals(neighbourhoodTextField.getText())) {
            dao = dao.filterByNeighbourhood(neighbourhoodTextField.getText());
        }

        // Input from assessment class text field.
        if (assessmentClassComboBox.getValue() != null && !"".equals(assessmentClassComboBox.getValue())) {
            dao = dao.filterByAssessmentClass(assessmentClassComboBox.getValue());
        }

        // Input min and max text fields.
        if (!"".equals(minTextField.getText()) && !"".equals(maxTextField.getText())) {
            try {
                int min = Integer.parseInt(minTextField.getText());
                int max = Integer.parseInt(maxTextField.getText());

                dao = dao.filterByAssessedValue(min, max);
            } catch (NumberFormatException e) {
                GuiUtility.showWarningWindow(
                        "Invalid Input",
                        "Invalid minimum or maximum value."
                );
                return;
            }
        } else if (!"".equals(minTextField.getText())) {
            try {
                int min = Integer.parseInt(minTextField.getText());

                dao = dao.filterByAssessedValue(min, -1);
            } catch (NumberFormatException e) {
                GuiUtility.showWarningWindow(
                        "Invalid Input",
                        "Invalid minimum or maximum value."
                );
                return;
            }
        } else if (!"".equals(maxTextField.getText())) {
            try {
                int max = Integer.parseInt(maxTextField.getText());

                dao = dao.filterByAssessedValue(-1, max);
            } catch (NumberFormatException e) {
                GuiUtility.showWarningWindow("Invalid Input", "Invalid minimum or maximum value.");
                return;
            }
        }

        // Execute filters from the chain.
        List<PropertyAssessment> assessments = dao.executeFilter();
        if (assessments == null || assessments.size() == 0) {
            GuiUtility.showWarningWindow(
                    "Search Results",
                    "Oops!, Cannot find a valid entry."
            );
            return;
        }

        // Fill the UI components with the input data.
        fillDataForNodes(assessments);
    }

    /**
     * Fills the combo option values for data source combo box.
     */
    private void fillDataSourceComboOptions() {
        List<DataSource> enumValues = new ArrayList<>(EnumSet.allOf(DataSource.class));
        dataSourceComboBox.setItems(FXCollections.observableList(enumValues));
    }

    /**
     * Fills the combo option values for assessment class combo box.
     */
    private void fillAssessmentClassComboOptions() {
        String[] assessmentClasses = {
                "",
                "FARMLAND",
                "NONRES MUNICIPAL/RES EDUCATION",
                "COMMERCIAL",
                "OTHER RESIDENTIAL",
                "RESIDENTIAL",
        };

        List<String> assessmentClassValues = Arrays.asList(assessmentClasses);

        assessmentClassComboBox.setItems(FXCollections.observableList(assessmentClassValues));
    }

    /**
     * Loads data from the given data source.
     */
    private void loadData() {
        DataSource dataSource = dataSourceComboBox.getValue();
        if (dataSource == null) {
            GuiUtility.showWarningWindow(
                    "Invalid data source",
                    "Please select a valid data source."
            );
        }

        // Load property assessment data.
        try {
            if (Objects.requireNonNull(dataSource) == DataSource.API) {
                propertyAssessmentDAO = new ApiPropertyAssessmentDAO();
                // By default, load the data from the csv file.
            } else {
                propertyAssessmentDAO = new CsvPropertyAssessmentDAO(Constants.CSV_FILENAME);
            }
        } catch (FileNotFoundException e) {
            GuiUtility.showWarningWindow("Something went wrong", "Something went wrong. Please restart the application.");
            e.printStackTrace();
        }
    }

    /**
     * Sets the width of the table column with respect to the table.
     *
     * @param tableColumn column of the table.
     * @param width       relative width of the column.
     */
    private void setTableColumnWidth(
            TableColumn<PropertyAssessment, ?> tableColumn,
            double width
    ) {
        tableColumn.prefWidthProperty().bind(assessmentsTable.widthProperty().multiply(width));
    }

    /**
     * Sets the width of each of the table columns with respect to the table itself.
     */
    private void setTableColumnWidths() {
        setTableColumnWidth(accountColumn, 0.075);
        setTableColumnWidth(addressColumn, 0.2);
        setTableColumnWidth(assessedValueColumn, 0.1);
        setTableColumnWidth(assessmentClassColumn, 0.2);
        setTableColumnWidth(neighbourhoodColumn, 0.2);
        setTableColumnWidth(locationColumn, 0.2);
    }

    /**
     * Maps the java object fields to their respective column values.
     */
    private void mapFieldToColumnValue(
            TableColumn<PropertyAssessment, ?> tableColumn,
            String fieldName
    ) {
        tableColumn.setCellValueFactory(new PropertyValueFactory<>(fieldName));
    }

    /**
     * Maps all the fields to table columns.
     */
    private void mapFieldsToColumnValues() {
        mapFieldToColumnValue(accountColumn, "accountNumber");
        mapFieldToColumnValue(addressColumn, "address");
        mapFieldToColumnValue(assessedValueColumn, "valueString");
        mapFieldToColumnValue(assessmentClassColumn, "assessmentClass");
        mapFieldToColumnValue(neighbourhoodColumn, "neighbourhood");
        mapFieldToColumnValue(locationColumn, "location");
    }

    /**
     * Fills the data for the table view.
     *
     * @param propertyAssessments list of property assessments to collect the data.
     */
    private void fillTable(List<PropertyAssessment> propertyAssessments) {
        List<PropertyAssessment> entries = new ArrayList<>(propertyAssessments);
        assessmentsTable.setItems(FXCollections.observableList(entries));
    }

    /**
     * Fills the data for the pie chart.
     *
     * @param propertyAssessments list of property assessments to collect the data.
     */
    private void fillPieChart(List<PropertyAssessment> propertyAssessments) {
        PropertyAssessments statistics = new PropertyAssessments(propertyAssessments);
        Map<String, Integer> assessmentClassCounts = statistics.propertyAssessmentClass1WithCount();
        ObservableList<PieChart.Data> dataEntries = FXCollections.observableArrayList();

        assessmentClassCounts.forEach((key, value) -> {
            dataEntries.add(new PieChart.Data(key, value));
        });

        assessedValuePieChart.setData(dataEntries);
    }

    /**
     * Fills the data for the bar chart.
     *
     * @param propertyAssessments list of property assessments to collect the data.
     */
    private void fillBarChart(List<PropertyAssessment> propertyAssessments) {
        PropertyAssessments statistics = new PropertyAssessments(propertyAssessments);
        Map<String, Integer> assessedValueRanges = statistics.assessedValueRangesWithCount();

        XYChart.Series<String, Integer> series = new XYChart.Series<>();

        assessedValueRanges.forEach((assessedValueRange, count) -> {
            series.getData().add(new XYChart.Data<>(assessedValueRange, count));
        });

        List<XYChart.Series<String, Integer>> seriesList = new ArrayList<>();
        seriesList.add(series);
        assessedValueBarChart.setData(FXCollections.observableList(seriesList));
    }

    /**
     * Fills the web view with Google Maps.
     *
     * @param propertyAssessments list of property assessments
     */
    private void fillMap(List<PropertyAssessment> propertyAssessments) {
        WebEngine webEngine = browser.getEngine();

        String jsonObjects = Utility.propertyAssessmentsToJsonString(propertyAssessments);
        String html = createHtml(jsonObjects);
        webEngine.loadContent(html);

        webEngine.getLoadWorker().stateProperty().addListener(
                (observableValue, oldValue, newValue) -> {
                    if (newValue == Worker.State.SUCCEEDED) {
                        // Set the selection listener once the DOM is loaded.
                        addTableSelectionListener();
                    }
                }
        );
    }

    /**
     * Fills data for all the nodes including tables, graphs, maps etc...
     *
     * @param propertyAssessments list of property assessments to fill data for nodes.
     */
    private void fillDataForNodes(List<PropertyAssessment> propertyAssessments) {
        fillTable(propertyAssessments);
        fillPieChart(propertyAssessments);
        fillBarChart(propertyAssessments);
        fillMap(propertyAssessments);
    }

    /**
     * Adds the selection listener to table rows.
     */
    private void addTableSelectionListener() {
        TableView.TableViewSelectionModel<PropertyAssessment> selectionModel = assessmentsTable.getSelectionModel();

        // Only allow single selection at a time.
        selectionModel.setSelectionMode(SelectionMode.SINGLE);

        // Selected items.
        ObservableList<PropertyAssessment> selectedItems = selectionModel.getSelectedItems();

        // Whenever a row is selected below method is called.
        selectedItems.addListener((ListChangeListener<PropertyAssessment>) change -> {
            if (change.getList().size() == 0) {
                return;
            }

            // Inside the HTML, javascript has an object named mapFunctions, which maps the account numbers
            // to a function.
            // The job of the function is to center the marker around the property.
            PropertyAssessment assessment = change.getList().get(0);
            String script = String.format("mapFunctions[%d]()", assessment.getAccountNumber());
            browser.getEngine().executeScript(script);
        });
    }

    /**
     * Clears the control fields.
     */
    private void clearControls() {
        TextField[] textFields = {
                accountNumberTextField,
                addressTextField,
                neighbourhoodTextField,
                minTextField,
                maxTextField,
        };

        // Clear all the text fields.
        Arrays.stream(textFields).forEach(TextInputControl::clear);

        // Clear the assessment class combo box.
        assessmentClassComboBox.setValue("");
    }

    /**
     * Clears the application nodes.
     */
    private void clearNodes() {
        // Clear the browser web engine.
        browser.getEngine().loadContent("""
                <h3 style="display: flex; align-items: center; justify-content: center;">
                    Please load data to view maps.
                </h3>
                """);

        // Clear all the data from the table.
        assessmentsTable.getItems().clear();

        // Clear the pie chart data.
        assessedValuePieChart.getData().clear();

        // Clear the bar chart data.
        assessedValueBarChart.getData().clear();
    }
}

