import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author Arshdeep Singh
 */
public class ApiPropertyAssessmentDAO implements PropertyAssessmentDAO {
    ApiRequest.Builder filterRequest = new ApiRequest.Builder();

    @Override
    public Optional<PropertyAssessment> getByAccountNumber(int accountNumber) {
        ApiRequest request = new ApiRequest.Builder().
                withAccountNumber(accountNumber).
                withLimit(1).
                build();

        List<PropertyAssessment> results;
        try {
            results = request.execute();
        } catch (IOException e) {
            return Optional.empty();
        }

        if (results == null || results.size() == 0) {
            return Optional.empty();
        }

        return Optional.of(results.get(0));
    }

    /**
     * Get all the entries by the neighbourhood.
     *
     * @param neighbourhood to find all the entries for.
     * @return All the entries in a given neighbourhood.
     */
    @Override
    public List<PropertyAssessment> getByNeighbourhood(String neighbourhood) {
        return filterByNeighbourhood(neighbourhood).executeFilter();
    }

    /**
     * Get all the entries by the address.
     *
     * @param address to find all the entries.
     * @return All the entries for the given address.
     */
    @Override
    public List<PropertyAssessment> getByAddress(String address) {
        return filterByAddress(address).executeFilter();
    }

    /**
     * Get all the entries for a given assessment class.
     *
     * @param assessmentClass to find all the entries.
     * @return All the entries for the given assessment class.
     */
    @Override
    public List<PropertyAssessment> getByAssessmentClass(String assessmentClass) {
        return filterByAssessmentClass(assessmentClass).executeFilter();
    }

    /**
     * Get all the entries within min and max assessed value range.
     *
     * @param min lower range.
     * @param max higher range.
     * @return entries within the given range.
     */
    @Override
    public List<PropertyAssessment> getByAssessedValue(int min, int max) {
        return filterByAssessedValue(min, max).executeFilter();
    }

    /**
     * Get all the entries.
     *
     * @return all entries.
     * @apiNote In order to improve performance api only returns 2000 entries.
     */
    @Override
    public List<PropertyAssessment> getAll() {
        List<PropertyAssessment> results = new ArrayList<>();

        try {
            results = new ApiRequest.Builder().withLimit(2000).build().execute();
            return results;
        } catch (IOException e) {
            return results;
        }
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by neighbourhood.
     *
     * @param neighbourhood filter by neighbourhood.
     * @return all entries in neighbourhood.
     */
    @Override
    public PropertyAssessmentDAO filterByNeighbourhood(String neighbourhood) {
        filterRequest.withNeighbourhood(neighbourhood);
        return this;
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by address.
     *
     * @param address filter by address.
     * @return all entries in address.
     */
    @Override
    public PropertyAssessmentDAO filterByAddress(String address) {
        filterRequest.withAddress(address);
        return this;
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by assessment class.
     *
     * @param assessmentClass filter by assessmentClass.
     * @return all entries in assessment class.
     */
    @Override
    public PropertyAssessmentDAO filterByAssessmentClass(String assessmentClass) {
        filterRequest.withAssessmentClass(assessmentClass);
        return this;
    }

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by min and max assessed value range.
     *
     * @param min range of assessed value.
     * @param max range of assessed value.
     * @return entries that are within the range.
     */
    @Override
    public PropertyAssessmentDAO filterByAssessedValue(int min, int max) {
        if (min == -1) {
            min = 0;
        }
        if (max == -1) {
            max = 0;
        }

        filterRequest.withAssessedValueRange(min, max);
        return this;
    }

    /**
     * Execute the filter chain.
     *
     * @return list after all the filters are applied.
     */
    @Override
    public List<PropertyAssessment> executeFilter() {
        ApiRequest request = filterRequest.build();

        try {
            List<PropertyAssessment> results = request.execute();
            filterRequest = new ApiRequest.Builder();

            return results;
        } catch (IOException e) {
            return null;
        }
    }
}
