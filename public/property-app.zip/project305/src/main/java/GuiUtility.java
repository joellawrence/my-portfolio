import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * @author arshdeepjodhka
 */
public class GuiUtility {
    /**
     * Shows the warning window with the given title and message.
     *
     * @param title   title of the window.
     * @param message warning message.
     */
    public static void showWarningWindow(String title, String message) {
        try {
            FXMLLoader loader = new FXMLLoader(GuiUtility.class.getResource("warning.fxml"));
            Stage stage = new Stage();

            // Explicitly set controller.
            WarningController warningController = new WarningController(stage, message);
            loader.setController(warningController);

            Scene scene = new Scene(loader.load(), 360, 120);
            stage.setTitle(title);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
