import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import org.apache.commons.collections4.list.UnmodifiableList;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Arshdeep Singh
 */
public class PropertyAssessments {
    private final List<PropertyAssessment> entries;

    /**
     * @param assessments list of property assessment.
     */
    public PropertyAssessments(List<PropertyAssessment> assessments) {
        // Sort the list before assigning it, it is important to note that the list is sorted
        // based on the assessed values of the properties.
        entries = assessments.
                stream().
                sorted().
                collect(Collectors.toList());
    }

    /**
     * Creates a new property assessments object from the given csv file.
     *
     * @param filename name of the csv file to parse the data.
     * @return property assessments.
     * @throws FileNotFoundException if file with given name does not exist.
     * @throws IllegalStateException if opencsv is unable to map to beans or parse the csv file.
     * @deprecated data loading is done through data access objects.
     */
    @Deprecated
    public static PropertyAssessments loadFromCsv(String filename)
            throws FileNotFoundException, IllegalStateException {
        FileReader reader = new FileReader(filename);

        // Build the csv parser.
        CsvToBean<PropertyAssessment> csvToBean = new CsvToBeanBuilder<PropertyAssessment>(reader).
                withType(PropertyAssessment.class).
                build();

        // Parse the csv file.
        List<PropertyAssessment> entries = csvToBean.parse();

        return new PropertyAssessments(entries);
    }

    /**
     * @return Unmodifiable list of property assessment entries.
     */
    public UnmodifiableList<PropertyAssessment> getEntries() {
        return new UnmodifiableList<>(entries);
    }

    /**
     * Creates a new property assessments object with entries matching the provided
     * neighbourhood
     *
     * @param neighbourhood name to filter the list.
     * @return list of filtered entries with the given neighbourhood.
     * @deprecated neighbourhood filter is replaced by property assessment data access object filters.
     */
    @Deprecated
    public PropertyAssessments filterByNeighbourhood(String neighbourhood) {
        List<PropertyAssessment> results = entries.stream().
                filter((assessment) -> assessment.
                        getNeighbourhood().
                        getNeighbourhood().
                        equalsIgnoreCase(neighbourhood)
                ).
                toList();

        return new PropertyAssessments(results);
    }

    /**
     * Creates a new property assessments object with entries matching the provided
     * assessment classes.
     *
     * @param assessmentClass to filter the list by. It can match any assessment class in
     *                        assessment class 1, 2 or 3
     * @return list of filtered entries with the given neighbourhood.
     * @deprecated assessment class filter is replaced by property assessment data access object filters.
     */
    @Deprecated
    public PropertyAssessments filterByAssessmentClass(String assessmentClass) {
        List<PropertyAssessment> results = entries.stream().
                filter((assessment) -> {
                    AssessmentClass assessmentClass1 = assessment.getAssessmentClass();

                    return assessmentClass1.getAssessmentClass1().equalsIgnoreCase(assessmentClass) ||
                            assessmentClass1.getAssessmentClass2().equalsIgnoreCase(assessmentClass) ||
                            assessmentClass1.getAssessmentClass3().equalsIgnoreCase(assessmentClass);
                }).
                toList();

        return new PropertyAssessments(results);
    }

    /**
     * @return The number of records.
     */
    public int numberOfRecords() {
        return entries.size();
    }

    /**
     * Calculates the number of distinct wards in Edmonton.
     *
     * @return The number of wards in entries.
     */
    public int numberOfWards() {
        Set<String> distinctWards = entries.stream().
                map((assessment) -> assessment.getNeighbourhood().getWard()).
                collect(Collectors.toSet());

        return distinctWards.size();
    }

    /**
     * Gets the lowest and highest assessed values out of all the property entries.
     *
     * @return AssessedValues with the lowest, highest and range of given values.
     */
    public PropertyAssessedValues lowestAndHighestAssessedValues() {
        // If the list is empty, return with 0 values.
        if (entries.size() == 0) {
            return new PropertyAssessedValues(0, 0, 0);
        }

        // Assign both the lowest and highest as the first entry in the list.
        long lowest = entries.get(0).getAssessedValue(), highest = lowest;

        for (PropertyAssessment assessment : entries) {
            long assessedValue = assessment.getAssessedValue();

            if (assessedValue < lowest) {
                lowest = assessedValue;
            }

            if (assessedValue > highest) {
                highest = assessedValue;
            }
        }

        long range = highest - lowest;

        return new PropertyAssessedValues(lowest, highest, range);
    }

    /**
     * Calculates the mean and median of all the assessed property values.
     *
     * @return mean and median of property assessed values.
     */
    public PropertyMeanMedian meanAndMedianOfAssessedValues() {
        int size = entries.size();

        if (size == 0) {
            return new PropertyMeanMedian(0, 0);
        }

        // It is important to note that the list was already sorted when it was initialized. Therefore,
        // the median is directly calculated.
        long median;
        if (size % 2 == 0) {
            median = (entries.get((size / 2) - 1).getAssessedValue() + entries.get(size / 2).getAssessedValue()) / 2;
        } else {
            median = entries.get(size / 2).getAssessedValue();
        }

        // Calculate mean.
        long sum = 0;
        for (PropertyAssessment assessment : entries) {
            sum += assessment.getAssessedValue();
        }
        long mean = Math.round((double) sum / size);

        return new PropertyMeanMedian(mean, median);
    }

    /**
     * Calculates and returns statistics for all the entries including lowest and highest
     * property assessed values, the range between them, and the mean and median of assessed
     * values.
     *
     * @return statistics for the given properties.
     */
    public PropertyStatistics descriptiveStatistics() {
        int numberOfRecords = numberOfRecords();
        PropertyAssessedValues assessedValues = lowestAndHighestAssessedValues();
        PropertyMeanMedian meanMedian = meanAndMedianOfAssessedValues();

        return new PropertyStatistics(numberOfRecords, assessedValues, meanMedian);
    }

    /**
     * Gets the set of all the assessment classes.
     *
     * @return assessment classes.
     */
    public Set<String> propertyAssessmentClasses() {
        Set<String> assessmentClasses = new HashSet<>();

        for (PropertyAssessment assessment : entries) {
            AssessmentClass assessmentClass = assessment.getAssessmentClass();

            assessmentClasses.add(assessmentClass.getAssessmentClass1());
            assessmentClasses.add(assessmentClass.getAssessmentClass2());
            assessmentClasses.add(assessmentClass.getAssessmentClass3());
        }

        // Remove if there is an empty string in the set.
        assessmentClasses.removeIf((assessmentClass) -> assessmentClass.length() == 0);

        return assessmentClasses;
    }

    /**
     * Gets the property assessment class 1 category with its recurring count.
     *
     * @return map of the property assessment class name along with the value.
     */
    public Map<String, Integer> propertyAssessmentClass1WithCount() {
        Map<String, Integer> assessmentClasses = new HashMap<>(10);

        entries.forEach((entry) -> {
            String assessmentClass = entry.getAssessmentClass().getAssessmentClass1();

            // If the key is already present on map, increment the value by 1.
            if (assessmentClasses.containsKey(assessmentClass)) {
                Integer value = assessmentClasses.get(assessmentClass);
                assessmentClasses.put(assessmentClass, value + 1);
            } else {
                // Else add the first key.
                assessmentClasses.put(assessmentClass, 1);
            }
        });

        return assessmentClasses;
    }

    /**
     * Classifies and puts different assessed values into different ranges.
     *
     * @return map of property assessed value ranges with the count of assessments in the given range.
     */
    public Map<String, Integer> assessedValueRangesWithCount() {
        Map<String, Integer> results = new TreeMap<>();

        // Assessed Value Categories.
        final String assessedValueRange1 = "000,000 - 200,000";
        final String assessedValueRange2 = "200,000 - 400,000";
        final String assessedValueRange3 = "400,000 - 600,000";
        final String assessedValueRange4 = "600,000 - 800,000";
        final String assessedValueRange5 = "800,000 and more";

        // Initialize all the categories with 0 entries.
        results.put(assessedValueRange1, 0);
        results.put(assessedValueRange2, 0);
        results.put(assessedValueRange3, 0);
        results.put(assessedValueRange4, 0);
        results.put(assessedValueRange5, 0);

        // For each entry classify the entry into a given range.
        entries.forEach((entry) -> {
            long assessedValue = entry.getAssessedValue();

            if (assessedValue < 200_000) {
                int currentCount = results.get(assessedValueRange1);
                results.put(assessedValueRange1, currentCount + 1);
            } else if (assessedValue < 400_000) {
                int currentCount = results.get(assessedValueRange2);
                results.put(assessedValueRange2, currentCount + 1);
            } else if (assessedValue < 600_000) {
                int currentCount = results.get(assessedValueRange3);
                results.put(assessedValueRange3, currentCount + 1);
            } else if (assessedValue < 800_000) {
                int currentCount = results.get(assessedValueRange4);
                results.put(assessedValueRange4, currentCount + 1);
            } else {
                int currentCount = results.get(assessedValueRange5);
                results.put(assessedValueRange5, currentCount + 1);
            }
        });

        return results;
    }


    /**
     * Gets the property assessment for the given account number.
     *
     * @param accountNumber to find the entry.
     * @return property assessment if found, else null.
     * @deprecated account number filter is replaced by property assessment data access object filters.
     */
    @Deprecated
    public PropertyAssessment getEntryByAccountNumber(int accountNumber) {
        Optional<PropertyAssessment> result = entries.stream().
                filter((assessment) -> assessment.getAccountNumber() == accountNumber).
                findFirst();

        if (result.isEmpty()) {
            return null;
        }

        return result.get();
    }
}
