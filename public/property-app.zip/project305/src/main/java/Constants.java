/**
 * @author Arshdeep Singh
 */
public class Constants {
    /**
     * Open csv profile to parse the data from file.
     */
    public static final String OPEN_CSV_PROFILE_FILE = "file";

    /**
     * Open csv profile to parse the data from api.
     */
    public static final String OPEN_CSV_PROFILE_API = "api";

    /**
     * Filename to parse csv.
     */
    public static final String CSV_FILENAME = "./Property_Assessment_Data_2022.csv";
}
