public record PropertyMeanMedian(long mean, long median) {
    @Override
    public String toString() {
        return "mean = $" + mean + "\n" +
                "median = $" + median;
    }
}
