import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author Arshdeep Singh
 */
public class Main extends Application {
    private static final String APPLICATION_TITLE = "Edmonton Property Assessments 2022";

    /**
     * To run the application, please use the following command.
     * <p>
     * mvn clean javafx:run
     */
    public static void main(String[] args) throws Exception {
        launch(args);
    }

    /**
     * Start is the main entrypoint of the application.
     *
     * @param stage the main application window.
     * @throws Exception exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("index.fxml"));
        Scene scene = new Scene(loader.load(), 1920, 1080);

        stage.setTitle(APPLICATION_TITLE);
        stage.setScene(scene);
        stage.show();
    }
}
