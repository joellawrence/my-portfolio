import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvBindByNames;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * @author Arshdeep Singh
 */
public class Location {
    @CsvBindByNames({
            @CsvBindByName(column = "Latitude", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "latitude", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final BigDecimal latitude;

    @CsvBindByNames({
            @CsvBindByName(column = "Longitude", profiles = Constants.OPEN_CSV_PROFILE_FILE),
            @CsvBindByName(column = "longitude", profiles = Constants.OPEN_CSV_PROFILE_API)
    })
    private final BigDecimal longitude;

    /**
     * Default constructor for the object. Sets all the fields to their default
     * values.
     */
    public Location() {
        this(new BigDecimal(0), new BigDecimal(0));
    }

    /**
     * Constructor for the location object.
     *
     * @param latitude  of a given location.
     * @param longitude of a given location.
     */
    public Location(BigDecimal latitude, BigDecimal longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    /**
     * @return latitude of a given location.
     */
    public BigDecimal getLatitude() {
        return new BigDecimal(String.valueOf(latitude));
    }

    /**
     * @return longitude of a given location.
     */
    public BigDecimal getLongitude() {
        return new BigDecimal(String.valueOf(longitude));
    }

    /**
     * Provides a string representation of the location.
     *
     * @return representation of object.
     */
    @Override
    public String toString() {
        return "(" + latitude + ", " + longitude + ")";
    }

    /**
     * Compares two objects based on their member fields.
     *
     * @param o other object to compare with current object.
     * @return true/false if the fields are same for both objects.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Location location = (Location) o;

        if (!Objects.equals(latitude, location.latitude)) {
            return false;
        }
        return Objects.equals(longitude, location.longitude);
    }

    /**
     * Calculates the hashcode of the object, based on its member fields.
     *
     * @return integer representing the calculated hash code of the object.
     */
    @Override
    public int hashCode() {
        int result = latitude != null ? latitude.hashCode() : 0;
        result = 31 * result + (longitude != null ? longitude.hashCode() : 0);
        return result;
    }
}
