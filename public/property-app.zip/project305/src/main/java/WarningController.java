import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * @author arshdeepjodhka
 */
public class WarningController {
    private final Stage stage;
    private final String message;

    @FXML
    private Label warningLabel;

    /**
     * Constructor for the object.
     *
     * @param stage   current stage of the warning label.
     * @param message warning message to show to the user.
     */
    public WarningController(Stage stage, String message) {
        this.message = message;
        this.stage = stage;
    }

    /**
     * Initialize the warning label with the following message.
     */
    @FXML
    public void initialize() {
        warningLabel.setText(message);
    }

    /**
     * When the ok button is clicked, close the stage.
     *
     * @param event button click event.
     */
    @FXML
    void okClick(ActionEvent event) {
        stage.close();
    }
}
