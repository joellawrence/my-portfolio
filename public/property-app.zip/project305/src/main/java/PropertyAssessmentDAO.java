import java.util.List;
import java.util.Optional;

/**
 * @author Arshdeep Singh
 */
public interface PropertyAssessmentDAO {
    /**
     * Get the entry by account number.
     *
     * @param accountNumber to find the entry.
     * @return optional entry if present.
     */
    Optional<PropertyAssessment> getByAccountNumber(int accountNumber);

    /**
     * Get all the entries by the neighbourhood.
     *
     * @param neighbourhood to find all the entries for.
     * @return All the entries in a given neighbourhood.
     */
    List<PropertyAssessment> getByNeighbourhood(String neighbourhood);

    /**
     * Get all the entries by the address.
     *
     * @param address to find all the entries.
     * @return All the entries for the given address.
     */
    List<PropertyAssessment> getByAddress(String address);

    /**
     * Get all the entries for a given assessment class.
     *
     * @param assessmentClass to find all the entries.
     * @return All the entries for the given assessment class.
     */
    List<PropertyAssessment> getByAssessmentClass(String assessmentClass);

    /**
     * Get all the entries within min and max assessed value range.
     *
     * @param min lower range.
     * @param max higher range.
     * @return entries within the given range.
     */
    List<PropertyAssessment> getByAssessedValue(int min, int max);

    /**
     * Get all the entries.
     *
     * @return all entries.
     */
    List<PropertyAssessment> getAll();

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by neighbourhood.
     *
     * @param neighbourhood filter by neighbourhood.
     * @return all entries in neighbourhood.
     */
    PropertyAssessmentDAO filterByNeighbourhood(String neighbourhood);

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by address.
     *
     * @param address filter by address.
     * @return all entries in address.
     */
    PropertyAssessmentDAO filterByAddress(String address);

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by assessment class.
     *
     * @param assessmentClass filter by assessmentClass.
     * @return all entries in assessment class.
     */
    PropertyAssessmentDAO filterByAssessmentClass(String assessmentClass);

    /**
     * Filters are used to chain and filter out data on multiple levels.
     * This one does by min and max assessed value range.
     *
     * @param min range of assessed value.
     * @param max range of assessed value.
     * @return entries that are within the range.
     */
    PropertyAssessmentDAO filterByAssessedValue(int min, int max);

    /**
     * Execute the filter chain.
     *
     * @return list after all the filters are applied.
     */
    List<PropertyAssessment> executeFilter();
}
