import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Arshdeep Singh
 */
public class Lab3Main {
    public static void main(String[] args) {
        run();
    }

    /**
     * Main entry point for lab 3 client program.
     */
    public static void run() {
        Scanner scanner = new Scanner(System.in);

        // Read filename from user.
        System.out.print("CSV filename: ");
        if (!scanner.hasNext()) {
            System.err.println("Invalid input");
            return;
        }
        String filename = scanner.nextLine();

        // Try loading the assessments data from file.
        PropertyAssessments assessments;
        try {
            assessments = PropertyAssessments.loadFromCsv(filename);
        } catch (FileNotFoundException e) {
            System.err.println("Error: cannot open file " + filename);
            return;
        } catch (IllegalStateException e) {
            e.printStackTrace();
            return;
        }

        // Read the assessment class.
        System.out.print("Assessment class: ");
        String assessmentClass = scanner.nextLine();

        // Print statistics for the filtered assessments.
        PropertyAssessments filteredAssessments = assessments.filterByAssessmentClass(assessmentClass);
        PropertyStatistics statistics = filteredAssessments.descriptiveStatistics();

        if (statistics.numberOfRecords() == 0) {
            System.out.println("Sorry assessment class does not exist");
            return;
        }

        System.out.println("Statistics (assessment class = " + assessmentClass + ")");
        System.out.println(statistics);
    }
}
