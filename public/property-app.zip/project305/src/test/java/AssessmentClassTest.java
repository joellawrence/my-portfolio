import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

/**
 * @author Arshdeep Singh
 */
class AssessmentClassTest {
    private final String ASSESSMENT_CLASS_1 = "Assessment Class 1";
    private final int ASSESSMENT_CLASS_1_PERCENTAGE = 10;
    private final String ASSESSMENT_CLASS_2 = "Assessment Class 2";
    private final int ASSESSMENT_CLASS_2_PERCENTAGE = 20;
    private final String ASSESSMENT_CLASS_3 = "Assessment Class 3";
    private final int ASSESSMENT_CLASS_3_PERCENTAGE = 30;

    /**
     * Address used for all the tests. It is important to note that since the object
     * is meant to be immutable, it is not reassigned before every test.
     */
    private final AssessmentClass assessmentClass = new AssessmentClass(
            ASSESSMENT_CLASS_1,
            ASSESSMENT_CLASS_1_PERCENTAGE,
            ASSESSMENT_CLASS_2,
            ASSESSMENT_CLASS_2_PERCENTAGE,
            ASSESSMENT_CLASS_3,
            ASSESSMENT_CLASS_3_PERCENTAGE
    );

    /**
     * Create default constructed object.
     *
     * @result Validates that the default constructed object has initialized all the member
     * fields to defaults.
     * In this case the String is initialized to empty string, and the int is initialized to 0
     */
    @Test
    void defaultConstructor() {
        AssessmentClass assessmentClass = new AssessmentClass();

        assertEquals("", assessmentClass.getAssessmentClass1());
        assertEquals(0, assessmentClass.getAssessmentClass1Percentage());
        assertEquals("", assessmentClass.getAssessmentClass2());
        assertEquals(0, assessmentClass.getAssessmentClass2Percentage());
        assertEquals("", assessmentClass.getAssessmentClass3());
        assertEquals(0, assessmentClass.getAssessmentClass3Percentage());
    }

    /**
     * Create an assessment class object with a custom constructor.
     *
     * @result Validates the custom constructed object has initialized all the member fields
     * with given values.
     */
    @Test
    void customConstructor() {
        AssessmentClass assessmentClass = new AssessmentClass(
                ASSESSMENT_CLASS_1,
                ASSESSMENT_CLASS_1_PERCENTAGE,
                ASSESSMENT_CLASS_2,
                ASSESSMENT_CLASS_2_PERCENTAGE,
                ASSESSMENT_CLASS_3,
                ASSESSMENT_CLASS_3_PERCENTAGE
        );

        assertEquals(ASSESSMENT_CLASS_1, assessmentClass.getAssessmentClass1());
        assertEquals(ASSESSMENT_CLASS_1_PERCENTAGE, assessmentClass.getAssessmentClass1Percentage());
        assertEquals(ASSESSMENT_CLASS_2, assessmentClass.getAssessmentClass2());
        assertEquals(ASSESSMENT_CLASS_2_PERCENTAGE, assessmentClass.getAssessmentClass2Percentage());
        assertEquals(ASSESSMENT_CLASS_3, assessmentClass.getAssessmentClass3());
        assertEquals(ASSESSMENT_CLASS_3_PERCENTAGE, assessmentClass.getAssessmentClass3Percentage());
    }

    /**
     * @result Checks the getter for the assessment class 1 percentage field.
     */
    @Test
    void getAssessmentClass1Percentage() {
        assertEquals(ASSESSMENT_CLASS_1_PERCENTAGE, assessmentClass.getAssessmentClass1Percentage());
    }

    /**
     * @result Checks the getter for the assessment class 1 field.
     */
    @Test
    void getAssessmentClass1() {
        assertEquals(ASSESSMENT_CLASS_1, assessmentClass.getAssessmentClass1());
    }

    /**
     * @result Checks the getter for the assessment class 2 percentage field.
     */
    @Test
    void getAssessmentClass2Percentage() {
        assertEquals(ASSESSMENT_CLASS_2_PERCENTAGE, assessmentClass.getAssessmentClass2Percentage());
    }

    /**
     * @result Checks the getter for the assessment class 2 field.
     */
    @Test
    void getAssessmentClass2() {
        assertEquals(ASSESSMENT_CLASS_2, assessmentClass.getAssessmentClass2());
    }

    /**
     * @result Checks the getter for the assessment class 3 percentage field.
     */
    @Test
    void getAssessmentClass3Percentage() {
        assertEquals(ASSESSMENT_CLASS_3_PERCENTAGE, assessmentClass.getAssessmentClass3Percentage());
    }

    /**
     * @result Checks the getter for the assessment class 3 field.
     */
    @Test
    void getAssessmentClass3() {
        assertEquals(ASSESSMENT_CLASS_3, assessmentClass.getAssessmentClass3());
    }

    /**
     * @result Validates the result of to string method.
     */
    @Test
    void testToString() {
        final String expected = "Assessment Class = [" +
                ASSESSMENT_CLASS_1 + " " + ASSESSMENT_CLASS_1_PERCENTAGE + "%, " +
                ASSESSMENT_CLASS_2 + " " + ASSESSMENT_CLASS_2_PERCENTAGE + "%, " +
                ASSESSMENT_CLASS_3 + " " + ASSESSMENT_CLASS_3_PERCENTAGE + "%" +
                "]";

        assertEquals(expected, assessmentClass.toString());
    }

    /**
     * @result Validates that two objects are not equal.
     */
    @Test
    void notEquals() {
        assertNotEquals(new AssessmentClass(), assessmentClass);
    }

    /**
     * @result Validates that two objects of different types are not equal.
     */
    @Test
    void notEqualsWithDifferentType() {
        assertNotEquals(10, assessmentClass);
    }

    /**
     * @result Validates the reflexivity property of the equals' method.
     */
    @Test
    void reflexiveEquals() {
        assertEquals(assessmentClass, assessmentClass);
    }

    /**
     * @result Validates the symmetric property of the equals' method.
     */
    @Test
    void symmetricEquals() {
        // other is same as the assessment class member field, it is only used to check
        // symmetric properties of equals method.
        final AssessmentClass other = new AssessmentClass(
                ASSESSMENT_CLASS_1,
                ASSESSMENT_CLASS_1_PERCENTAGE,
                ASSESSMENT_CLASS_2,
                ASSESSMENT_CLASS_2_PERCENTAGE,
                ASSESSMENT_CLASS_3,
                ASSESSMENT_CLASS_3_PERCENTAGE
        );

        assertEquals(other, assessmentClass);
        assertEquals(assessmentClass, other);
    }

    /**
     * @result Validates the transitive property of equals' method.
     */
    @Test
    void transitiveEquals() {
        final AssessmentClass x = new AssessmentClass(
                ASSESSMENT_CLASS_1,
                ASSESSMENT_CLASS_1_PERCENTAGE,
                ASSESSMENT_CLASS_2,
                ASSESSMENT_CLASS_2_PERCENTAGE,
                ASSESSMENT_CLASS_3,
                ASSESSMENT_CLASS_3_PERCENTAGE
        );
        final AssessmentClass y = new AssessmentClass(
                ASSESSMENT_CLASS_1,
                ASSESSMENT_CLASS_1_PERCENTAGE,
                ASSESSMENT_CLASS_2,
                ASSESSMENT_CLASS_2_PERCENTAGE,
                ASSESSMENT_CLASS_3,
                ASSESSMENT_CLASS_3_PERCENTAGE
        );
        final AssessmentClass z = new AssessmentClass(
                ASSESSMENT_CLASS_1,
                ASSESSMENT_CLASS_1_PERCENTAGE,
                ASSESSMENT_CLASS_2,
                ASSESSMENT_CLASS_2_PERCENTAGE,
                ASSESSMENT_CLASS_3,
                ASSESSMENT_CLASS_3_PERCENTAGE
        );

        assertEquals(x, y);
        assertEquals(y, z);
        assertEquals(x, z);
    }

    /**
     * @result Validates the consistency property of equals' method.
     */
    @Test
    void consistentEquals() {
        final AssessmentClass other = new AssessmentClass(
                ASSESSMENT_CLASS_1,
                ASSESSMENT_CLASS_1_PERCENTAGE,
                ASSESSMENT_CLASS_2,
                ASSESSMENT_CLASS_2_PERCENTAGE,
                ASSESSMENT_CLASS_3,
                ASSESSMENT_CLASS_3_PERCENTAGE
        );

        assertEquals(other, assessmentClass);
        assertEquals(other, assessmentClass);
        assertEquals(other, assessmentClass);
        assertEquals(other, assessmentClass);
    }

    /**
     * @result Validates that setting null as a parameter will give false.
     */
    @Test
    void nullEquals() {
        assertNotEquals(null, assessmentClass);
    }

    /**
     * @result Validates that equal objects have the same hashcode.
     */
    @Test
    void hashCodeForEqualObjects() {
        final AssessmentClass other = new AssessmentClass(
                ASSESSMENT_CLASS_1,
                ASSESSMENT_CLASS_1_PERCENTAGE,
                ASSESSMENT_CLASS_2,
                ASSESSMENT_CLASS_2_PERCENTAGE,
                ASSESSMENT_CLASS_3,
                ASSESSMENT_CLASS_3_PERCENTAGE
        );

        assertEquals(other.hashCode(), assessmentClass.hashCode());
    }

    /**
     * @result Validates that equal objects have
     */
    @Test
    void hashCodeForUnequalObjects() {
        final AssessmentClass other = new AssessmentClass();

        assertNotEquals(other.hashCode(), assessmentClass.hashCode());
    }
}