import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class LocationTest {
    private final BigDecimal LATITUDE = BigDecimal.valueOf(53.63049663158542);
    private final BigDecimal LONGITUDE = BigDecimal.valueOf(-113.5804742693191);

    private final Location location = new Location(LATITUDE, LONGITUDE);

    /**
     * Create default constructed object.
     *
     * @result Validates that the default constructed object has initialized all the member
     * fields to defaults.
     * In this case the BigDecimal values must have value of 0.
     */
    @Test
    void defaultConstructor() {
        Location location = new Location();

        // Check for equality of default values.
        assertEquals(BigDecimal.valueOf(0), location.getLatitude());
        assertEquals(BigDecimal.valueOf(0), location.getLongitude());
    }

    /**
     * Create a location object with a custom constructor.
     *
     * @result Validates the custom constructed object has initialized all the member fields
     * with given values.
     */
    @Test
    void customConstructor() {
        Location location = new Location(LATITUDE, LONGITUDE);

        assertEquals(LATITUDE, location.getLatitude());
        assertEquals(LONGITUDE, location.getLongitude());
    }

    /**
     * @result Checks the getter for latitude.
     */
    @Test
    void getLatitude() {
        assertEquals(LATITUDE, location.getLatitude());
    }

    /**
     * @result Checks the getter for longitude.
     */
    @Test
    void getLongitude() {
        assertEquals(LONGITUDE, location.getLongitude());
    }

    /**
     * Checks the string representation of the object.
     *
     * @result Validates that the given representation of location object matches
     * the one implemented inside the location object.
     */
    @Test
    void testToString() {
        final String expected = "Location = (" + LATITUDE + ", " + LONGITUDE + ")";

        assertEquals(expected, location.toString());
    }


    /**
     * @result Validates that two objects are not equal.
     */
    @Test
    void notEquals() {
        assertNotEquals(new Location(), location);
    }

    /**
     * @result Validates that two objects of different types are not equal.
     */
    @Test
    void notEqualsWithDifferentType() {
        assertNotEquals(10, location);
    }

    /**
     * @result Validates the reflexivity property of the equals' method.
     */
    @Test
    void reflexiveEquals() {
        assertEquals(location, location);
    }

    /**
     * @result Validates the symmetric property of the equals' method.
     */
    @Test
    void symmetricEquals() {
        // other is same as the assessment class member field, it is only used to check
        // symmetric properties of equals method.
        final Location other = new Location(
                LATITUDE,
                LONGITUDE
        );

        assertEquals(other, location);
        assertEquals(location, other);
    }

    /**
     * @result Validates the transitive property of equals' method.
     */
    @Test
    void transitiveEquals() {
        final Location x = new Location(
                LATITUDE,
                LONGITUDE
        );
        final Location y = new Location(
                LATITUDE,
                LONGITUDE
        );
        final Location z = new Location(
                LATITUDE,
                LONGITUDE
        );

        assertEquals(x, y);
        assertEquals(y, z);
        assertEquals(x, z);
    }

    /**
     * @result Validates the consistency property of equals' method.
     */
    @Test
    void consistentEquals() {
        final Location other = new Location(
                LATITUDE,
                LONGITUDE
        );

        assertEquals(other, location);
        assertEquals(other, location);
        assertEquals(other, location);
        assertEquals(other, location);
    }

    /**
     * @result Validates that setting null as a parameter will give false.
     */
    @Test
    void nullEquals() {
        assertNotEquals(null, location);
    }

    /**
     * @result Validates that equal objects have the same hashcode.
     */
    @Test
    void hashCodeForEqualObjects() {
        final Location other = new Location(
                LATITUDE,
                LONGITUDE
        );

        assertEquals(other.hashCode(), location.hashCode());
    }

    /**
     * @result Validates that equal objects have
     */
    @Test
    void hashCodeForUnequalObjects() {
        final Location other = new Location();

        assertNotEquals(other.hashCode(), location.hashCode());
    }
}