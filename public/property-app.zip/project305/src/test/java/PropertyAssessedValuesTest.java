import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PropertyAssessedValuesTest {
    private final long LOWEST = 10;
    private final long HIGHEST = 100;
    private final long RANGE = HIGHEST - LOWEST;

    private final PropertyAssessedValues assessedValues = new PropertyAssessedValues(
            LOWEST,
            HIGHEST,
            RANGE
    );

    /**
     * Checks the string representation of the object.
     *
     * @result Validates that the given representation of object matches
     * the one implemented inside the property assessed value object.
     */
    @Test
    void testToString() {
        final String expected = "min = $" + LOWEST + "\n" +
                "max = $" + HIGHEST + "\n" +
                "range = $" + RANGE;

        assertEquals(expected, assessedValues.toString());
    }

    /**
     * @result Checks the getter for the lowest value.
     */
    @Test
    void lowest() {
        assertEquals(LOWEST, assessedValues.lowest());
    }

    /**
     * @result Checks the getter for the highest value.
     */
    @Test
    void highest() {
        assertEquals(HIGHEST, assessedValues.highest());
    }

    /**
     * @result Checks the getter for the range value.
     */
    @Test
    void range() {
        assertEquals(RANGE, assessedValues.range());
    }
}