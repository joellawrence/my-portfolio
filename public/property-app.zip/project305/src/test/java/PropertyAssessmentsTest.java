import org.apache.commons.collections4.list.UnmodifiableList;
import org.junit.jupiter.api.Test;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class PropertyAssessmentsTest {
    /**
     * PropertyAssessments object used for all the tests.
     */
    private final PropertyAssessments testAssessments = new PropertyAssessments(
            createTestAssessmentEntries()
    );

    /**
     * Creates the test assessment entries, all the tests will be based on these entries.
     * It is important to note that these entries are the same ones present in the file
     * Test_Property_Assessment_Data_2022.csv. These are just manually constructed to be validated
     * the entries from the file, and also for ease of testing.
     *
     * @return list of PropertyAssessment objects.
     */
    private List<PropertyAssessment> createTestAssessmentEntries() {
        List<PropertyAssessment> results = new ArrayList<>();

        // Create first row instance of Test_Property_Assessment_Data_2022.csv.
        PropertyAssessment p1 = new PropertyAssessment(
                1066158,
                new Address("", 14904, "167 AVENUE NW"),
                false,
                new Neighbourhood(0, "", ""),
                86000,
                new Location(
                        new BigDecimal("53.63049663158542"),
                        new BigDecimal("-113.5804742693191")
                ),
                new AssessmentClass(
                        "RESIDENTIAL",
                        100,
                        "",
                        0,
                        "",
                        0
                )
        );


        // Create second row instance of Test_Property_Assessment_Data_2022.csv.
        PropertyAssessment p2 = new PropertyAssessment(
                1194653,
                new Address("", 8319, "156 AVENUE NW"),
                false,
                new Neighbourhood(2050, "BELLE RIVE", "tastawiyiniwak Ward"),
                257000,
                new Location(
                        new BigDecimal("53.616237298079405"),
                        new BigDecimal("-113.46941226946224")
                ),
                new AssessmentClass(
                        "RESIDENTIAL",
                        100,
                        "",
                        0,
                        "",
                        0
                )
        );

        // Create third row instance of Test_Property_Assessment_Data_2022.csv.
        PropertyAssessment p3 = new PropertyAssessment(
                1034321,
                new Address("", 11020, "JASPER AVENUE NW"),
                false,
                new Neighbourhood(1150, "OLIVER", "O-day'min Ward"),
                62112000,
                new Location(
                        new BigDecimal("53.541279206311984"),
                        new BigDecimal("-113.51143504606169")
                ),
                new AssessmentClass(
                        "OTHER RESIDENTIAL",
                        95,
                        "COMMERCIAL",
                        5,
                        "",
                        0
                )
        );

        // Create fourth row instance of Test_Property_Assessment_Data_2022.csv.
        PropertyAssessment p4 = new PropertyAssessment(
                1114974,
                new Address("", 14902, "RIO TERRACE DRIVE NW"),
                true,
                new Neighbourhood(4430, "RIO TERRACE", "sipiwiyiniwak Ward"),
                842000,
                new Location(
                        new BigDecimal("53.50760246690828"),
                        new BigDecimal("-113.57858852769932")
                ),
                new AssessmentClass(
                        "RESIDENTIAL",
                        100,
                        "",
                        0,
                        "",
                        0
                )
        );

        // Add test entries into the list.
        results.add(p1);
        results.add(p2);
        results.add(p3);
        results.add(p4);

        return results;
    }

    /**
     * @result Validates for the invalid filename, FileNotFoundException is thrown.
     */
    @Test
    void loadFromCsvWithInvalidFilename() {
        assertThrows(FileNotFoundException.class, () -> {
            PropertyAssessments.loadFromCsv("invalid.csv");
        });
    }

    /**
     * @result Validates that for a valid filename, no exception is thrown.
     */
    @Test
    void loadFromCsvWithValidFilename() {
        assertDoesNotThrow(() -> {
            PropertyAssessments.loadFromCsv("Test_Property_Assessment_Data_2022.csv");
        });
    }

    /**
     * @result Loads the test csv file into the PropertyAssessments object, and
     * validates the file entries are equal to test entries.
     */
    @Test
    void loadFromCsvWithValidFilenameAndValidateEntries() {
        PropertyAssessments assessments;
        try {
            assessments = PropertyAssessments.loadFromCsv("Test_Property_Assessment_Data_2022.csv");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return;
        }

        UnmodifiableList<PropertyAssessment> entries = assessments.getEntries();

        // For all the entries in the list.
        for (PropertyAssessment entry : entries) {
            Optional<PropertyAssessment> expected = testAssessments.getEntries().
                    stream().
                    filter((assessment) -> assessment.getAccountNumber() == entry.getAccountNumber()).
                    findFirst();

            // Validate the entry from the csv file, is the same entry in test data.
            expected.ifPresent((assessment) -> assertEquals(assessment, entry));
        }
    }

    /**
     * @result Validates the neighbourhood filter, by providing a neighbourhood name entries for
     * which are present in the list, and therefore entries are returned. The entry is validated
     * by comparing the account numbers.
     */
    @Test
    void filterByNeighbourhoodWithValidNeighbourhood() {
        // Filter neighbourhood name is used to filter the list of property assessments
        // with the given neighbourhood name.
        final String FILTER_NEIGHBOURHOOD_NAME = "Belle rive";
        // Filter neighbourhood account number is the account number associated with the
        // above neighbourhood name.
        final int FILTER_NEIGHBOURHOOD_ACCOUNT_NUMBER = 1194653;

        PropertyAssessments assessments = testAssessments.filterByNeighbourhood(
                FILTER_NEIGHBOURHOOD_NAME
        );

        // Get the element at the first index, the filtered element will always be
        // at index 0, because the test list is small subset of the original list
        // and therefore only has one entry with given neighbourhood.
        PropertyAssessment result = assessments.getEntries().get(0);

        // Validate that both entries have the same account number.
        assertEquals(FILTER_NEIGHBOURHOOD_ACCOUNT_NUMBER, result.getAccountNumber());
    }

    /**
     * @result Validates the neighbourhood filter, by providing a neighbourhood name entries for
     * which are absent in the list, and list of size 0 is returned.
     */
    @Test
    void filterByNeighbourhoodWithInvalidNeighbourhood() {
        // Filter is randomly chosen, and no entry with the given neighbourhood name
        // exists in the list.
        final String FILTER_NEIGHBOURHOOD_NAME = "Random";

        PropertyAssessments assessments = testAssessments.filterByNeighbourhood(
                FILTER_NEIGHBOURHOOD_NAME
        );

        UnmodifiableList<PropertyAssessment> entries = assessments.getEntries();

        // Validate that list with 0 elements is returned.
        assertEquals(0, entries.size());
    }

    /**
     * @result Validates the assessment class filter, by providing an assessment class name to filter entries
     * which are present in the list. The entry is validated by comparing the number of entries with the
     * given assessment class.
     */
    @Test
    void filterByAssessmentClassWithValidAssessmentClass() {
        // Filter assessment class is used to filter the list of property assessments
        // based on the assessment class.
        final String FILTER_ASSESSMENT_CLASS = "Residential";
        final int FILTER_ASSESSMENTS_EXPECTED_SIZE = 3;

        PropertyAssessments assessments = testAssessments.filterByAssessmentClass(
                FILTER_ASSESSMENT_CLASS
        );

        List<PropertyAssessment> entries = assessments.getEntries();

        // Validate that the list has 3 elements in it.
        assertEquals(FILTER_ASSESSMENTS_EXPECTED_SIZE, entries.size());
    }

    /**
     * @result Validates the assessment class filter, by providing an assessment class name
     * that has no associated entries with it, and list of size 0 is returned.
     */
    @Test
    void filterByAssessmentClassWithInvalidAssessmentClass() {
        // Filter is randomly chosen, and no entry with the given assessment class name
        // exists in the list.
        final String FILTER_ASSESSMENT_CLASS = "Random";

        PropertyAssessments assessments = testAssessments.filterByAssessmentClass(
                FILTER_ASSESSMENT_CLASS
        );

        UnmodifiableList<PropertyAssessment> entries = assessments.getEntries();

        // Validates that the list has 0 elements in it.
        assertEquals(0, entries.size());
    }

    /**
     * @result Validates the number of records in the test assessments. It does it by
     * manually checking the number of entries in the test list.
     */
    @Test
    void numberOfRecords() {
        assertEquals(4, testAssessments.numberOfRecords());
    }

    /**
     * @result Validates the number of different wards in the test assessments. It does it by
     * manually checking the number of different wards in test list.
     */
    @Test
    void numberOfWards() {
        assertEquals(4, testAssessments.numberOfWards());
    }

    /**
     * @result Validates the lowest and highest extracted value in the test assessments. It compares
     * the values calculated by the program and the ones that are calculated by hand by looking over test
     * data.
     */
    @Test
    void lowestAndHighestAssessedValues() {
        PropertyAssessedValues values = testAssessments.lowestAndHighestAssessedValues();

        assertEquals(86000, values.lowest());
        assertEquals(62112000, values.highest());
        assertEquals(62026000, values.range());
    }

    /**
     * @result Validates the mean and the median. It compares the values calculated by the program and the ones
     * that are calculated by hand by looking over the test data.
     */
    @Test
    void meanAndMedianOfAssessedValues() {
        PropertyMeanMedian meanMedian = testAssessments.meanAndMedianOfAssessedValues();

        assertEquals(15824250, meanMedian.mean());
        assertEquals(549500, meanMedian.median());
    }

    /**
     * @result Validates all the descriptive statistics. It compares the previously calculated values by hand and
     * the ones calculated by the program.
     */
    @Test
    void descriptiveStatistics() {
        // These are the expected descriptive statistics calculated by hand from the test data.
        PropertyStatistics expected = new PropertyStatistics(
                4,
                new PropertyAssessedValues(86000, 62112000, 62026000),
                new PropertyMeanMedian(15824250, 549500)
        );

        assertEquals(expected, testAssessments.descriptiveStatistics());
    }

    /**
     * @result Validates the all the different assessment classes in the data are returned.
     */
    @Test
    void propertyAssessmentClasses() {
        final Set<String> expected = new HashSet<>();
        expected.add("RESIDENTIAL");
        expected.add("OTHER RESIDENTIAL");
        expected.add("COMMERCIAL");

        assertEquals(expected, testAssessments.propertyAssessmentClasses());
    }

    /**
     * @result Validates that the list entry returned for a given account number is valid.
     */
    @Test
    void getEntryByAccountNumberForValidAccountNumber() {
        final int EXPECTED_ACCOUNT_NUMBER = 1066158;
        PropertyAssessment assessment = testAssessments.getEntryByAccountNumber(EXPECTED_ACCOUNT_NUMBER);

        assertEquals(EXPECTED_ACCOUNT_NUMBER, assessment.getAccountNumber());
    }

    /**
     * @result Validates that for an invalid account number the entry returned is null.
     */
    @Test
    void getEntryByAccountNumberForInvalidAccountNumber() {
        final int EXPECTED_ACCOUNT_NUMBER = 0;

        assertNull(testAssessments.getEntryByAccountNumber(EXPECTED_ACCOUNT_NUMBER));
    }
}