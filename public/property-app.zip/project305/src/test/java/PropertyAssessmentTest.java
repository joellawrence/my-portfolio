import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class PropertyAssessmentTest {
    private final PropertyAssessment assessment = new PropertyAssessment(
            1114974,
            new Address("", 14902, "RIO TERRACE DRIVE NW"),
            true,
            new Neighbourhood(4430, "RIO TERRACE", "sipiwiyiniwak Ward"),
            842000,
            new Location(
                    new BigDecimal("53.50760246690828"),
                    new BigDecimal("-113.57858852769932")
            ),
            new AssessmentClass(
                    "RESIDENTIAL",
                    100,
                    "",
                    0,
                    "",
                    0
            )
    );

    private final PropertyAssessment other = new PropertyAssessment(
            1114974,
            new Address("", 14902, "RIO TERRACE DRIVE NW"),
            true,
            new Neighbourhood(4430, "RIO TERRACE", "sipiwiyiniwak Ward"),
            842000,
            new Location(
                    new BigDecimal("53.50760246690828"),
                    new BigDecimal("-113.57858852769932")
            ),
            new AssessmentClass(
                    "RESIDENTIAL",
                    100,
                    "",
                    0,
                    "",
                    0
            )
    );

    /**
     * Creates a property assessment instance with the given assessed values.
     * Most of the member fields are left blank, it is only used to create instances
     * to validate the comparisons between property assessments.
     *
     * @param assessedValue assessed value of the property entry.
     * @return property assessment object.
     */
    private static PropertyAssessment createPropertyInstance(long assessedValue) {
        return new PropertyAssessment(
                1,
                new Address(),
                false,
                new Neighbourhood(),
                assessedValue,
                new Location(),
                new AssessmentClass()
        );
    }

    /**
     * Validates the functionality of Comparable interface implementation.
     * The property assessment class overrides the compareTo method which
     * compares the assessed values of two given properties.
     *
     * @result Test 1 of compareTo, which validates if the value is less than
     * the other value, compareTo must return a negative number.
     */
    @Test
    void compareToLessThan() {
        // p1 has assessed value less than p2.
        PropertyAssessment p1 = createPropertyInstance(10);
        PropertyAssessment p2 = createPropertyInstance(20);

        // Validate the comparison returns a negative number.
        assertTrue(p1.compareTo(p2) < 0);
    }

    /**
     * @result Test 2 of compareTo, which validates if the value is equals to
     * the other value, compareTo must return 0.
     */
    @Test
    void compareToEquals() {
        PropertyAssessment p1 = createPropertyInstance(10);
        PropertyAssessment p2 = createPropertyInstance(10);

        // Validate the comparison returns 0.
        assertEquals(0, p1.compareTo(p2));
    }

    /**
     * @result Test 3 of compareTo, which validates if the value is greater to
     * the other value, compareTo must return a positive number.
     */
    @Test
    void compareToGreaterThan() {
        PropertyAssessment p1 = createPropertyInstance(20);
        PropertyAssessment p2 = createPropertyInstance(10);

        // Validate th comparison returns a positive number.
        assertTrue(p1.compareTo(p2) > 0);
    }

    /**
     * @result Validates that two objects are not equal.
     */
    @Test
    void notEquals() {
        assertNotEquals(new PropertyAssessment(), assessment);
    }

    @Test
    void notEqualsWithDifferentType() {
        assertNotEquals(10, assessment);
    }

    /**
     * @result Validates the reflexivity property of the equals' method.
     */
    @Test
    void reflexiveEquals() {
        assertEquals(assessment, assessment);
    }

    /**
     * @result Validates the symmetric property of the equals' method.
     */
    @Test
    void symmetricEquals() {
        assertEquals(other, assessment);
        assertEquals(assessment, other);
    }

    /**
     * @result Validates the transitive property of equals' method.
     */
    @Test
    void transitiveEquals() {
        PropertyAssessment x = new PropertyAssessment(
                1114974,
                new Address("", 14902, "RIO TERRACE DRIVE NW"),
                true,
                new Neighbourhood(4430, "RIO TERRACE", "sipiwiyiniwak Ward"),
                842000,
                new Location(
                        new BigDecimal("53.50760246690828"),
                        new BigDecimal("-113.57858852769932")
                ),
                new AssessmentClass(
                        "RESIDENTIAL",
                        100,
                        "",
                        0,
                        "",
                        0
                )
        );
        PropertyAssessment y = new PropertyAssessment(
                1114974,
                new Address("", 14902, "RIO TERRACE DRIVE NW"),
                true,
                new Neighbourhood(4430, "RIO TERRACE", "sipiwiyiniwak Ward"),
                842000,
                new Location(
                        new BigDecimal("53.50760246690828"),
                        new BigDecimal("-113.57858852769932")
                ),
                new AssessmentClass(
                        "RESIDENTIAL",
                        100,
                        "",
                        0,
                        "",
                        0
                )
        );
        PropertyAssessment z = new PropertyAssessment(
                1114974,
                new Address("", 14902, "RIO TERRACE DRIVE NW"),
                true,
                new Neighbourhood(4430, "RIO TERRACE", "sipiwiyiniwak Ward"),
                842000,
                new Location(
                        new BigDecimal("53.50760246690828"),
                        new BigDecimal("-113.57858852769932")
                ),
                new AssessmentClass(
                        "RESIDENTIAL",
                        100,
                        "",
                        0,
                        "",
                        0
                )
        );

        assertEquals(x, y);
        assertEquals(y, z);
        assertEquals(x, z);
    }

    /**
     * @result Validates the consistency property of equals' method.
     */
    @Test
    void consistentEquals() {
        assertEquals(other, assessment);
        assertEquals(other, assessment);
        assertEquals(other, assessment);
        assertEquals(other, assessment);
    }

    /**
     * @result Validates that setting null as a parameter will give false.
     */
    @Test
    void nullEquals() {
        assertNotEquals(null, assessment);
    }

    /**
     * @result Validates that equal objects have the same hashcode.
     */
    @Test
    void hashCodeForEqualObjects() {
        assertEquals(other.hashCode(), assessment.hashCode());
    }

    /**
     * @result Validates that equal objects have
     */
    @Test
    void hashCodeForUnequalObjects() {
        final AssessmentClass other = new AssessmentClass();

        assertNotEquals(other.hashCode(), assessment.hashCode());
    }
}