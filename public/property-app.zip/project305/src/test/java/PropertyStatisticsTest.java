import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PropertyStatisticsTest {
    private final int NUMBER_OF_RECORDS = 13;
    private final PropertyAssessedValues ASSESSED_VALUES = new PropertyAssessedValues(10, 11, 12);

    private final  PropertyMeanMedian MEAN_MEDIAN= new PropertyMeanMedian(12, 13);


    private final PropertyStatistics statistics = new PropertyStatistics(NUMBER_OF_RECORDS, ASSESSED_VALUES, MEAN_MEDIAN);

    /**
     * Checks the string representation of the object.
     *
     * @result Validates that the given representation of object matches
     * the one implemented inside the property assessed value object.
     */
    @Test
    void testToString() {
        final String expected = "n = " + NUMBER_OF_RECORDS + "\n" +
                ASSESSED_VALUES + "\n" +
                MEAN_MEDIAN;
    }

    @Test
    void numberOfRecords() {
    }

    @Test
    void assessedValues() {
    }

    @Test
    void meanMedian() {
    }
}