import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

/**
 * @author Arshdeep Singh
 */
class AddressTest {
    /**
     * Suite used for all the tests.
     */
    private final String SUITE = "Test Suite";

    /**
     * House number used for all the tests.
     */
    private final int HOUSE_NUMBER = 13;

    /**
     * Street name used for all the tests.
     */
    private final String STREET_NAME = "Test Street Name";

    /**
     * Address used for all the tests. It is important to note that since the object
     * is meant to be immutable, it is not reassigned before every test.
     */
    private final Address address = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);

    /**
     * Create default constructed object.
     *
     * @result Validates that the default constructed object has initialized all the member
     * fields to defaults.
     * In this case the String is initialized to empty string, and the int is initialized to 0
     */
    @Test
    void defaultConstructor() {
        Address address = new Address();

        // Check for equality of default values.
        assertEquals(address.getSuite(), "");
        assertEquals(address.getHouseNumber(), 0);
        assertEquals(address.getStreetName(), "");
    }

    /**
     * Create an address object with a custom constructor.
     *
     * @result Validates the custom constructed object has initialized all the member fields
     * with given values.
     */
    @Test
    void customConstructor() {
        Address address = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);

        assertEquals(SUITE, address.getSuite());
        assertEquals(HOUSE_NUMBER, address.getHouseNumber());
        assertEquals(STREET_NAME, address.getStreetName());
    }

    /**
     * Checks the getter for suite member field.
     *
     * @result Validates that the address has the same value of the member suite,
     * which was used to initialize the address object.
     */
    @Test
    void getSuite() {
        assertEquals(SUITE, address.getSuite());
    }

    /**
     * Checks the getter for houseNumber member field.
     *
     * @result Validates the address has the same value of member houseNumber,
     * which was used to initialize the address object.
     */
    @Test
    void getHouseNumber() {
        assertEquals(HOUSE_NUMBER, address.getHouseNumber());
    }

    /**
     * Checks the getter for streetName member field.
     *
     * @result Validates the address has the same value of member streetName,
     * which was used to initialize the address object.
     */
    @Test
    void getStreetName() {
        assertEquals(STREET_NAME, address.getStreetName());
    }

    /**
     * Checks the string representation of the object.
     *
     * @result Validates that the given representation of address object matches
     * the one implemented inside the address object.
     */
    @Test
    void testToString() {
        final String expected = "Address = " + SUITE + " " + HOUSE_NUMBER + " " + STREET_NAME;

        assertEquals(expected, address.toString());
    }

    /**
     * @result Validates that two objects are not equal.
     */
    @Test
    void notEquals() {
        assertNotEquals(new Address(), address);
    }

    @Test
    void notEqualsWithDifferentType() {
        assertNotEquals(10, address);
    }

    /**
     * @result Validates the reflexivity property of the equals' method.
     */
    @Test
    void reflexiveEquals() {
        assertEquals(address, address);
    }

    /**
     * @result Validates the symmetric property of the equals' method.
     */
    @Test
    void symmetricEquals() {
        // other is same as the address member field, it is only used to check
        // symmetric properties of equals method.
        final Address other = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);

        assertEquals(other, address);
        assertEquals(address, other);
    }

    /**
     * @result Validates the transitive property of equals' method.
     */
    @Test
    void transitiveEquals() {
        final Address x = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);
        final Address y = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);
        final Address z = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);

        assertEquals(x, y);
        assertEquals(y, z);
        assertEquals(x, z);
    }

    /**
     * @result Validates the consistency property of equals' method.
     */
    @Test
    void consistentEquals() {
        final Address other = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);

        assertEquals(other, address);
        assertEquals(other, address);
        assertEquals(other, address);
        assertEquals(other, address);
    }

    /**
     * @result Validates that setting null as a parameter will give false.
     */
    @Test
    void nullEquals() {
        assertNotEquals(null, address);
    }

    /**
     * @result Validates that equal objects have the same hashcode.
     */
    @Test
    void hashCodeForEqualObjects() {
        final Address other = new Address(SUITE, HOUSE_NUMBER, STREET_NAME);

        assertEquals(other.hashCode(), address.hashCode());
    }

    /**
     * @result Validates that equal objects have
     */
    @Test
    void hashCodeForUnequalObjects() {
        final Address other = new Address();

        assertNotEquals(other.hashCode(), address.hashCode());
    }
}