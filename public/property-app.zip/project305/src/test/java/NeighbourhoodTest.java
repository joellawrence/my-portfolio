import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

class NeighbourhoodTest {
    private final int NEIGHBOURHOOD_ID = 10;
    private final String NEIGHBOURHOOD_NAME = "Test neighbourhood";
    private final String WARD = "Test ward";

    private final Neighbourhood neighbourhood = new Neighbourhood(
            NEIGHBOURHOOD_ID,
            NEIGHBOURHOOD_NAME,
            WARD
    );

    @Test
    void defaultConstructor() {
        Neighbourhood neighbourhood = new Neighbourhood();

        assertEquals(0, neighbourhood.getNeighbourhoodId());
        assertEquals("", neighbourhood.getNeighbourhood());
        assertEquals("", neighbourhood.getWard());
    }

    /**
     * Create a neighbourhood object with a custom constructor.
     *
     * @result Validates the custom constructed object has initialized all the member fields
     * with given values.
     */
    @Test
    void customConstructor() {
        Neighbourhood neighbourhood = new Neighbourhood(
                NEIGHBOURHOOD_ID,
                NEIGHBOURHOOD_NAME,
                WARD
        );

        assertEquals(NEIGHBOURHOOD_ID, neighbourhood.getNeighbourhoodId());
        assertEquals(NEIGHBOURHOOD_NAME, neighbourhood.getNeighbourhood());
        assertEquals(WARD, neighbourhood.getWard());
    }

    /**
     * @result Checks the getter for neighbourhood id.
     */
    @Test
    void getNeighbourhoodId() {
        assertEquals(NEIGHBOURHOOD_ID, neighbourhood.getNeighbourhoodId());
    }

    /**
     * @result Checks the getter for neighbourhood.
     */
    @Test
    void getNeighbourhood() {
        assertEquals(NEIGHBOURHOOD_NAME, neighbourhood.getNeighbourhood());
    }

    /**
     * @result Checks the getter for ward.
     */
    @Test
    void getWard() {
        assertEquals(WARD, neighbourhood.getWard());
    }

    /**
     * Checks the string representation of the object.
     *
     * @result Validates that the given representation of location object matches
     * the one implemented inside the location object.
     */
    @Test
    void testToString() {
        final String expected = "Neighbourhood = " + NEIGHBOURHOOD_NAME + " (" + WARD + ")";

        assertEquals(expected, neighbourhood.toString());
    }


    /**
     * @result Validates that two objects are not equal.
     */
    @Test
    void notEquals() {
        assertNotEquals(new Neighbourhood(), neighbourhood);
    }

    /**
     * @result Validates two objects with different types are not equal.
     */
    @Test
    void notEqualsWithDifferentType() {
        assertNotEquals(10, neighbourhood);
    }

    /**
     * @result Validates the reflexivity property of the equals' method.
     */
    @Test
    void reflexiveEquals() {
        assertEquals(neighbourhood, neighbourhood);
    }

    /**
     * @result Validates the symmetric property of the equals' method.
     */
    @Test
    void symmetricEquals() {
        // other is same as the address member field, it is only used to check
        // symmetric properties of equals method.
        final Neighbourhood other = new Neighbourhood(
                NEIGHBOURHOOD_ID,
                NEIGHBOURHOOD_NAME,
                WARD
        );

        assertEquals(other, neighbourhood);
        assertEquals(neighbourhood, other);
    }

    /**
     * @result Validates the transitive property of equals' method.
     */
    @Test
    void transitiveEquals() {
        final Neighbourhood x = new Neighbourhood(
                NEIGHBOURHOOD_ID,
                NEIGHBOURHOOD_NAME,
                WARD
        );
        final Neighbourhood y = new Neighbourhood(
                NEIGHBOURHOOD_ID,
                NEIGHBOURHOOD_NAME,
                WARD
        );
        final Neighbourhood z = new Neighbourhood(
                NEIGHBOURHOOD_ID,
                NEIGHBOURHOOD_NAME,
                WARD
        );

        assertEquals(x, y);
        assertEquals(y, z);
        assertEquals(x, z);
    }

    /**
     * @result Validates the consistency property of equals' method.
     */
    @Test
    void consistentEquals() {
        final Neighbourhood other = new Neighbourhood(
                NEIGHBOURHOOD_ID,
                NEIGHBOURHOOD_NAME,
                WARD
        );

        assertEquals(other, neighbourhood);
        assertEquals(other, neighbourhood);
        assertEquals(other, neighbourhood);
        assertEquals(other, neighbourhood);
    }

    /**
     * @result Validates that setting null as a parameter will give false.
     */
    @Test
    void nullEquals() {
        assertNotEquals(null, neighbourhood);
    }

    /**
     * @result Validates that equal objects have the same hashcode.
     */
    @Test
    void hashCodeForEqualObjects() {
        final Neighbourhood other = new Neighbourhood(
                NEIGHBOURHOOD_ID,
                NEIGHBOURHOOD_NAME,
                WARD
        );

        assertEquals(other.hashCode(), neighbourhood.hashCode());
    }

    /**
     * @result Validates that equal objects have
     */
    @Test
    void hashCodeForUnequalObjects() {
        final Neighbourhood other = new Neighbourhood();

        assertNotEquals(other.hashCode(), neighbourhood.hashCode());
    }

}