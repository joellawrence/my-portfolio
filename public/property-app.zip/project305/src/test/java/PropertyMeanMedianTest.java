import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PropertyMeanMedianTest {
    private final long MEAN = 1313;
    private final long MEDIAN = 1314;

    private final PropertyMeanMedian meanMedian = new PropertyMeanMedian(MEAN, MEDIAN);

    /**
     * Checks the string representation of the object.
     *
     * @result Validates that the given representation of address object matches
     * the one implemented inside the property mean median value object.
     */
    @Test
    void testToString() {
        final String expected = "mean = $" + MEAN + "\n" +
                "median = $" + MEDIAN;

        assertEquals(expected, meanMedian.toString());
    }

    /**
     * Checks the getter for the mean value.
     */
    @Test
    void mean() {
        assertEquals(MEAN, meanMedian.mean());
    }

    /**
     * Checks the getter for the median value.
     */
    @Test
    void median() {
        assertEquals(MEDIAN, meanMedian.median());
    }
}